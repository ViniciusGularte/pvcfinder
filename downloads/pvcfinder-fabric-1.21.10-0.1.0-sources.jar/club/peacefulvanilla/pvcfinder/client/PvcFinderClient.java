package club.peacefulvanilla.pvcfinder.client;

import club.peacefulvanilla.pvcfinder.data.PvcOffer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_1937;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_3675;
import net.minecraft.class_5321;
import net.minecraft.class_638;
import net.minecraft.class_9779;
import java.util.List;
import java.util.Locale;

public final class PvcFinderClient {
    private static final int HUD_SURFACE = 0xE60F0B08;
    private static final int HUD_SURFACE_ALT = 0xD91A1209;
    private static final int HUD_BORDER = 0xFF7B4B25;
    private static final int HUD_ACCENT = 0xFFE8760A;
    private static final int HUD_EMERALD = 0xFF4ADE80;
    private static final int HUD_DIAMOND = 0xFF67E8F9;
    private static final int HUD_DANGER = 0xFFE35C5C;
    private static final int HUD_TEXT_BRIGHT = 0xFFF5F0E8;
    private static final int HUD_TEXT = 0xFFD8CCBC;
    private static final int HUD_TEXT_MUTED = 0xFFBCAE9C;

    private static final class_304 OPEN_BROWSER_KEY = new class_304(
            "key.pvcfinder.open",
            class_3675.class_307.field_1668,
            class_3675.field_32028,
            class_304.class_11900.field_62556
    );
    private static final PvcFinderDataStore DATA_STORE = new PvcFinderDataStore();
    private static TrackedShopTarget trackedTarget;
    private static int particleTicker;
    private static int hudIntroTicks;
    private static int hudPulseTicks;
    private static int dimensionReadyTicks;
    private static boolean sameDimensionLastTick;
    private static boolean bootstrapped;

    private PvcFinderClient() {
    }

    public static void bootstrap() {
        if (bootstrapped) {
            return;
        }
        bootstrapped = true;
        KeyBindingHelper.registerKeyBinding(OPEN_BROWSER_KEY);
        ClientTickEvents.END_CLIENT_TICK.register(PvcFinderClient::onClientTick);
        HudRenderCallback.EVENT.register(PvcFinderClient::renderHud);
    }

    public static void onClientTick(class_310 minecraft) {
        ClientNukeEffect.tick(minecraft);
        ImaginaryFriendController.tick(minecraft);
        if (minecraft.field_1724 == null) {
            return;
        }

        while (OPEN_BROWSER_KEY.method_1436()) {
            DATA_STORE.ensureLoaded(minecraft);
            minecraft.method_1507(new PvcFinderScreen(DATA_STORE));
        }

        tickTrackedTarget(minecraft);
    }

    public static void toggleTracking(class_310 minecraft, PvcOffer offer) {
        if (isTracked(offer)) {
            clearTracking(minecraft, class_2561.method_43471("message.pvcfinder.tracking_cleared"), false);
            return;
        }

        trackedTarget = TrackedShopTarget.fromOffer(offer);
        particleTicker = 0;
        hudIntroTicks = 0;
        hudPulseTicks = 18;
        dimensionReadyTicks = 0;
        sameDimensionLastTick = minecraft.field_1687 != null && minecraft.field_1687.method_27983().equals(trackedTarget.dimension());
        minecraft.field_1724.method_7353(
                class_2561.method_43469(
                        "message.pvcfinder.tracking_started",
                        offer.shop().displayName(),
                        offer.shop().coordsLabel(),
                        offer.shop().dimensionLabel()
                ),
                true
        );
    }

    public static boolean isTracked(PvcOffer offer) {
        return trackedTarget != null && trackedTarget.offerId().equals(offer.id());
    }

    public static TrackedShopTarget trackedTarget() {
        return trackedTarget;
    }

    public static void clearTrackingFromScreen(class_310 minecraft) {
        if (trackedTarget != null) {
            clearTracking(minecraft, class_2561.method_43471("message.pvcfinder.tracking_cleared"), false);
        }
    }

    public static boolean triggerTrackedNuke(class_310 minecraft) {
        return ClientNukeEffect.trigger(minecraft);
    }

    public static boolean toggleImaginaryFriend(class_310 minecraft) {
        return ImaginaryFriendController.toggle(minecraft);
    }

    public static boolean isImaginaryFriendActive() {
        return ImaginaryFriendController.isActive();
    }

    public static class_2561 trackingStatus(class_310 minecraft) {
        if (trackedTarget == null) {
            return class_2561.method_43471("screen.pvcfinder.tracking_none");
        }
        if (minecraft.field_1687 == null || minecraft.field_1724 == null) {
            return class_2561.method_43469("screen.pvcfinder.tracking_other_dimension", trackedTarget.label());
        }
        if (!minecraft.field_1687.method_27983().equals(trackedTarget.dimension())) {
            if (supportsScaledProjection(minecraft.field_1687.method_27983(), trackedTarget.dimension())) {
                class_243 projected = projectTargetIntoDimension(class_243.method_24953(trackedTarget.position()), minecraft.field_1687.method_27983(), trackedTarget.dimension());
                double projectedDistance = minecraft.field_1724.method_73189().method_1022(projected);
                return class_2561.method_43470(
                        "Tracking " + trackedTarget.label()
                                + " | shop in " + dimensionName(trackedTarget.dimension())
                                + " | approx " + formatDistance(projectedDistance) + " here"
                );
            }
            return class_2561.method_43469("screen.pvcfinder.tracking_other_dimension", trackedTarget.label());
        }
        return class_2561.method_43469(
                "screen.pvcfinder.tracking_active",
                trackedTarget.label(),
                trackedTarget.position().method_10263(),
                trackedTarget.position().method_10264(),
                trackedTarget.position().method_10260()
        );
    }

    public static String offerDistanceLabel(class_310 minecraft, PvcOffer offer) {
        if (minecraft.field_1724 == null || minecraft.field_1687 == null) {
            return "distance unavailable";
        }
        if (!minecraft.field_1687.method_27983().equals(offer.shop().dimension())) {
            if (supportsScaledProjection(minecraft.field_1687.method_27983(), offer.shop().dimension())) {
                class_243 projected = projectTargetIntoDimension(class_243.method_24953(offer.shop().position()), minecraft.field_1687.method_27983(), offer.shop().dimension());
                return "~" + formatDistance(minecraft.field_1724.method_73189().method_1022(projected)) + " on this axis";
            }
            return offer.shop().dimensionLabel();
        }
        double distance = minecraft.field_1724.method_73189().method_1022(class_243.method_24953(offer.shop().position()));
        return formatDistance(distance) + " away";
    }

    private static void renderHud(class_332 guiGraphics, class_9779 deltaTracker) {
        class_310 minecraft = class_310.method_1551();
        if (!(minecraft.field_1755 instanceof PvcFinderScreen)) {
            ClientNukeEffect.renderOverlay(minecraft, guiGraphics);
        }
        if (trackedTarget == null || minecraft.field_1724 == null) {
            return;
        }
        if (minecraft.field_1755 instanceof PvcFinderScreen) {
            return;
        }

        int width = minecraft.method_22683().method_4486();
        int centerX = width / 2;
        boolean sameDimension = minecraft.field_1687 != null && minecraft.field_1687.method_27983().equals(trackedTarget.dimension());
        boolean projectedDimension = minecraft.field_1687 != null && supportsScaledProjection(minecraft.field_1687.method_27983(), trackedTarget.dimension());
        float intro = easeOutCubic(class_3532.method_15363(hudIntroTicks / 10.0F, 0.0F, 1.0F));
        float alphaFactor = 0.45F + (0.55F * intro);
        float pulseFactor = hudPulseTicks > 0 ? (hudPulseTicks / 18.0F) : 0.0F;
        int top = 8 - Math.round((1.0F - intro) * 10.0F);
        String title = trackedTarget.label();
        int accentColor = sameDimension ? HUD_EMERALD : HUD_ACCENT;
        int pulseAccent = blendColor(accentColor, HUD_TEXT_BRIGHT, pulseFactor * 0.35F);

        if (!sameDimension && !projectedDimension) {
            String detail = "Switch to " + dimensionName(trackedTarget.dimension());
            int chipWidth = Math.min(230, Math.max(160, Math.max(minecraft.field_1772.method_1727(title), minecraft.field_1772.method_1727(detail)) + 24));
            int chipLeft = centerX - (chipWidth / 2);
            int chipRight = centerX + (chipWidth / 2);
            guiGraphics.method_25294(chipLeft, top, chipRight, top + 24, withAlpha(HUD_SURFACE, alphaFactor));
            guiGraphics.method_25294(chipLeft, top, chipRight, top + 2, withAlpha(pulseAccent, alphaFactor));
            guiGraphics.method_25300(minecraft.field_1772, minecraft.field_1772.method_27523(title, chipWidth - 18), centerX, top + 5, withAlpha(HUD_TEXT_BRIGHT, alphaFactor));
            guiGraphics.method_25300(minecraft.field_1772, minecraft.field_1772.method_27523(detail, chipWidth - 18), centerX, top + 15, withAlpha(HUD_ACCENT, alphaFactor));
            return;
        }

        class_243 playerPos = minecraft.field_1724.method_73189();
        class_243 target = sameDimension
                ? class_243.method_24953(trackedTarget.position())
                : projectTargetIntoDimension(class_243.method_24953(trackedTarget.position()), minecraft.field_1687.method_27983(), trackedTarget.dimension());
        double distance = playerPos.method_1022(target);
        double horizontalDistance = horizontalDistance(playerPos, target);
        float nearFade = distance <= 14.0D
                ? class_3532.method_15363((float) ((distance - 5.0D) / 9.0D), 0.0F, 1.0F)
                : 1.0F;
        alphaFactor *= 0.35F + (0.65F * nearFade);
        float relativeYaw = relativeYawToTarget(minecraft, target);
        String arrow = arrowLabel(relativeYaw);
        String distanceLabel = projectedDimension ? "~" + formatDistance(distance) : formatDistance(distance);
        boolean targetBehind = Math.abs(relativeYaw) > 135.0F;
        int mainWidth = Math.min(248, Math.max(176, Math.max(minecraft.field_1772.method_1727(title) + minecraft.field_1772.method_1727(distanceLabel) + 38, 176)));
        int animatedWidth = Math.max(116, class_3532.method_15375(mainWidth * intro));
        int drawLeft = centerX - (animatedWidth / 2);
        int drawRight = centerX + (animatedWidth / 2);
        int arrowColor = targetBehind ? HUD_DANGER : (Math.abs(relativeYaw) < 10.0F ? HUD_EMERALD : HUD_ACCENT);
        int maxOffset = Math.min((animatedWidth / 2) - 22, 76);
        int markerX = centerX + Math.round(class_3532.method_15363(relativeYaw / 90.0F, -1.0F, 1.0F) * maxOffset);
        String elevationBadge = elevationBadge(playerPos, target, horizontalDistance);
        String dimensionBadge = projectedDimension ? "SHOP IN " + dimensionName(trackedTarget.dimension()).toUpperCase(Locale.ROOT) : null;

        guiGraphics.method_25294(drawLeft, top, drawRight, top + 28, withAlpha(HUD_SURFACE, alphaFactor));
        guiGraphics.method_25294(drawLeft, top, drawRight, top + 2, withAlpha(blendColor(arrowColor, HUD_TEXT_BRIGHT, pulseFactor * 0.35F), alphaFactor));
        if (intro > 0.35F) {
            guiGraphics.method_51433(minecraft.field_1772, minecraft.field_1772.method_27523(title, animatedWidth - 86), drawLeft + 8, top + 5, withAlpha(HUD_TEXT_BRIGHT, alphaFactor), false);
            guiGraphics.method_51433(minecraft.field_1772, distanceLabel, drawRight - minecraft.field_1772.method_1727(distanceLabel) - 8, top + 5, withAlpha(HUD_TEXT, alphaFactor), false);
            guiGraphics.method_25294(drawLeft + 20, top + 18, drawRight - 20, top + 19, withAlpha(HUD_BORDER, alphaFactor));
            guiGraphics.method_51433(minecraft.field_1772, "L", drawLeft + 12, top + 14, withAlpha(HUD_TEXT_MUTED, alphaFactor), false);
            guiGraphics.method_51433(minecraft.field_1772, "R", drawRight - 18, top + 14, withAlpha(HUD_TEXT_MUTED, alphaFactor), false);
            guiGraphics.method_25294(markerX - 14, top + 14, markerX + 14, top + 26, withAlpha(HUD_SURFACE_ALT, alphaFactor));
            guiGraphics.method_25294(markerX - 14, top + 14, markerX + 14, top + 16, withAlpha(blendColor(arrowColor, HUD_TEXT_BRIGHT, pulseFactor * 0.35F), alphaFactor));
            guiGraphics.method_25300(minecraft.field_1772, arrow, markerX, top + 18, withAlpha(arrowColor, alphaFactor));
            if (targetBehind) {
                int tagWidth = minecraft.field_1772.method_1727("BEHIND") + 10;
                int tagLeft = drawRight - tagWidth - 8;
                guiGraphics.method_25294(tagLeft, top + 14, drawRight - 8, top + 25, withAlpha(HUD_SURFACE_ALT, alphaFactor));
                guiGraphics.method_25294(tagLeft, top + 14, drawRight - 8, top + 16, withAlpha(HUD_DANGER, alphaFactor));
                guiGraphics.method_25300(minecraft.field_1772, "BEHIND", tagLeft + (tagWidth / 2), top + 17, withAlpha(HUD_TEXT_BRIGHT, alphaFactor));
            }
        }

        if (intro > 0.55F) {
            String pulseBadge = dimensionReadyTicks > 0 && !projectedDimension ? "DIM OK" : null;
            renderHudBadges(guiGraphics, minecraft, centerX, top + 31, alphaFactor, pulseBadge, dimensionBadge, elevationBadge);
        }
    }

    private static void tickTrackedTarget(class_310 minecraft) {
        if (trackedTarget == null || minecraft.field_1724 == null || minecraft.field_1687 == null) {
            return;
        }

        if (hudIntroTicks < 10) {
            hudIntroTicks++;
        }
        if (hudPulseTicks > 0) {
            hudPulseTicks--;
        }
        if (dimensionReadyTicks > 0) {
            dimensionReadyTicks--;
        }

        boolean sameDimension = minecraft.field_1687.method_27983().equals(trackedTarget.dimension());
        if (sameDimension && !sameDimensionLastTick) {
            hudPulseTicks = 18;
            dimensionReadyTicks = 20;
        }
        sameDimensionLastTick = sameDimension;

        if (!sameDimension) {
            return;
        }

        class_243 targetCenter = class_243.method_24953(trackedTarget.position());
        double distanceSqr = minecraft.field_1724.method_73189().method_1025(targetCenter);
        if (distanceSqr <= 25.0D) {
            clearTracking(minecraft, class_2561.method_43471("message.pvcfinder.arrived"), true);
            return;
        }

        double distance = Math.sqrt(distanceSqr);
        int particleInterval = distance < 12.0D ? 8 : 4;
        if (++particleTicker % particleInterval != 0) {
            return;
        }

        spawnMarkerParticles(minecraft.field_1687, trackedTarget.position(), distance);
    }

    private static void spawnMarkerParticles(class_638 level, net.minecraft.class_2338 position, double distance) {
        double centerX = position.method_10263() + 0.5D;
        double centerY = position.method_10264() + 0.2D;
        double centerZ = position.method_10260() + 0.5D;
        int pillarSteps = distance < 10.0D ? 8 : 16;
        int ringParticles = distance < 10.0D ? 8 : 14;
        int crownParticles = distance < 10.0D ? 6 : 10;

        for (int step = 0; step < pillarSteps; step++) {
            level.method_8494(
                    class_2398.field_11207,
                    centerX,
                    centerY + (step * 0.42D),
                    centerZ,
                    0.0D,
                    0.01D,
                    0.0D
            );
        }

        for (int index = 0; index < ringParticles; index++) {
            double angle = (Math.PI * 2.0D * index) / ringParticles;
            level.method_8494(
                    class_2398.field_11211,
                    centerX + Math.cos(angle) * 1.15D,
                    centerY + 0.05D,
                    centerZ + Math.sin(angle) * 1.15D,
                    0.0D,
                    0.02D,
                    0.0D
            );
        }

        for (int index = 0; index < crownParticles; index++) {
            double angle = (Math.PI * 2.0D * index) / crownParticles;
            level.method_8494(
                    class_2398.field_11207,
                    centerX + Math.cos(angle) * 0.35D,
                    centerY + (pillarSteps * 0.42D),
                    centerZ + Math.sin(angle) * 0.35D,
                    0.0D,
                    0.0D,
                    0.0D
            );
        }
    }

    private static void clearTracking(class_310 minecraft, class_2561 message, boolean actionBar) {
        trackedTarget = null;
        particleTicker = 0;
        hudIntroTicks = 0;
        hudPulseTicks = 0;
        dimensionReadyTicks = 0;
        sameDimensionLastTick = false;
        if (minecraft.field_1724 != null) {
            minecraft.field_1724.method_7353(message, actionBar);
        }
    }

    private static int withAlpha(int color, float factor) {
        int alpha = (color >>> 24) & 0xFF;
        int red = (color >>> 16) & 0xFF;
        int green = (color >>> 8) & 0xFF;
        int blue = color & 0xFF;
        int scaledAlpha = class_3532.method_15340(Math.round(alpha * factor), 0, 255);
        return (scaledAlpha << 24) | (red << 16) | (green << 8) | blue;
    }

    private static int blendColor(int from, int to, float amount) {
        float clamped = class_3532.method_15363(amount, 0.0F, 1.0F);
        int fromA = (from >>> 24) & 0xFF;
        int fromR = (from >>> 16) & 0xFF;
        int fromG = (from >>> 8) & 0xFF;
        int fromB = from & 0xFF;
        int toA = (to >>> 24) & 0xFF;
        int toR = (to >>> 16) & 0xFF;
        int toG = (to >>> 8) & 0xFF;
        int toB = to & 0xFF;
        int outA = class_3532.method_15375(class_3532.method_16439(clamped, fromA, toA));
        int outR = class_3532.method_15375(class_3532.method_16439(clamped, fromR, toR));
        int outG = class_3532.method_15375(class_3532.method_16439(clamped, fromG, toG));
        int outB = class_3532.method_15375(class_3532.method_16439(clamped, fromB, toB));
        return (outA << 24) | (outR << 16) | (outG << 8) | outB;
    }

    private static void renderHudBadges(class_332 guiGraphics, class_310 minecraft, int centerX, int top, float alphaFactor, String firstBadge, String secondBadge, String thirdBadge) {
        List<String> badges = java.util.stream.Stream.of(firstBadge, secondBadge, thirdBadge)
                .filter(label -> label != null && !label.isBlank())
                .toList();
        if (badges.isEmpty()) {
            return;
        }

        int totalWidth = 0;
        for (String badge : badges) {
            totalWidth += minecraft.field_1772.method_1727(badge) + 12;
        }
        totalWidth += (badges.size() - 1) * 6;
        int x = centerX - (totalWidth / 2);
        float badgeAlpha = Math.min(alphaFactor, 0.78F);
        for (String badge : badges) {
            int badgeWidth = minecraft.field_1772.method_1727(badge) + 12;
            int accent = badge.startsWith("SHOP IN") ? HUD_ACCENT : (badge.startsWith("DIM") ? HUD_EMERALD : HUD_DIAMOND);
            guiGraphics.method_25294(x, top, x + badgeWidth, top + 12, withAlpha(HUD_SURFACE_ALT, badgeAlpha));
            guiGraphics.method_25294(x, top, x + badgeWidth, top + 2, withAlpha(accent, badgeAlpha));
            guiGraphics.method_25300(minecraft.field_1772, badge, x + (badgeWidth / 2), top + 3, withAlpha(HUD_TEXT_BRIGHT, badgeAlpha));
            x += badgeWidth + 6;
        }
    }

    private static float easeOutCubic(float value) {
        float inverted = 1.0F - value;
        return 1.0F - (inverted * inverted * inverted);
    }

    private static float relativeYawToTarget(class_310 minecraft, class_243 target) {
        if (minecraft.field_1724 == null) {
            return 0.0F;
        }
        double dx = target.field_1352 - minecraft.field_1724.method_23317();
        double dz = target.field_1350 - minecraft.field_1724.method_23321();
        float targetYaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0F;
        return class_3532.method_15393(targetYaw - minecraft.field_1724.method_36454());
    }

    private static String arrowLabel(float relativeYaw) {
        float absolute = Math.abs(relativeYaw);
        if (absolute < 10.0F) {
            return "^";
        }
        if (absolute < 40.0F) {
            return relativeYaw < 0.0F ? "<^" : "^>";
        }
        if (absolute < 120.0F) {
            return relativeYaw < 0.0F ? "<<" : ">>";
        }
        return relativeYaw < 0.0F ? "v<" : ">v";
    }

    private static String formatDistance(double distance) {
        if (distance >= 1_000_000.0D) {
            return String.format(Locale.ROOT, "%.1fM blocks", distance / 1_000_000.0D);
        }
        if (distance >= 1_000.0D) {
            return String.format(Locale.ROOT, "%.1fk blocks", distance / 1_000.0D);
        }
        return Math.round(distance) + " blocks";
    }

    private static String elevationBadge(class_243 playerPos, class_243 targetPos, double horizontalDistance) {
        if (horizontalDistance > 48.0D) {
            return null;
        }
        double deltaY = targetPos.field_1351 - playerPos.field_1351;
        if (deltaY >= 4.0D) {
            return "ABOVE " + Math.round(deltaY);
        }
        if (deltaY <= -4.0D) {
            return "BELOW " + Math.round(Math.abs(deltaY));
        }
        return horizontalDistance <= 18.0D ? "LEVEL" : null;
    }

    private static double horizontalDistance(class_243 from, class_243 to) {
        double dx = to.field_1352 - from.field_1352;
        double dz = to.field_1350 - from.field_1350;
        return Math.sqrt((dx * dx) + (dz * dz));
    }

    private static boolean supportsScaledProjection(class_5321<class_1937> currentDimension, class_5321<class_1937> targetDimension) {
        return (class_1937.field_25180.equals(currentDimension) && class_1937.field_25179.equals(targetDimension))
                || (class_1937.field_25179.equals(currentDimension) && class_1937.field_25180.equals(targetDimension));
    }

    private static class_243 projectTargetIntoDimension(class_243 target, class_5321<class_1937> currentDimension, class_5321<class_1937> targetDimension) {
        if (class_1937.field_25180.equals(currentDimension) && class_1937.field_25179.equals(targetDimension)) {
            return new class_243(target.field_1352 / 8.0D, target.field_1351, target.field_1350 / 8.0D);
        }
        if (class_1937.field_25179.equals(currentDimension) && class_1937.field_25180.equals(targetDimension)) {
            return new class_243(target.field_1352 * 8.0D, target.field_1351, target.field_1350 * 8.0D);
        }
        return target;
    }

    private static String dimensionName(class_5321<class_1937> dimension) {
        if (class_1937.field_25180.equals(dimension)) {
            return "Nether";
        }
        if (class_1937.field_25181.equals(dimension)) {
            return "End";
        }
        return "Overworld";
    }
}
