package club.peacefulvanilla.pvcfinder.client;

import java.util.Random;
import net.minecraft.class_1109;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3532;

public final class ClientNukeEffect {
    private static final Random RANDOM = new Random();
    private static final class_2960 NUCLEAR_ALARM_ID =
            class_2960.method_60655("pvcfinder", "nuclear_alarm");
    private static final class_3414 NUCLEAR_ALARM_EVENT =
            class_3414.method_47908(NUCLEAR_ALARM_ID);
    private static final int COUNTDOWN_TICKS = 600;
    private static final int DETONATION_TICKS = 360;
    private static final int HEAVY_SHAKE_TICKS = 220;
    private static final int RUMBLE_TICKS = 320;
    private static final int COLOR_WARNING = 0xFFFFE7C2;
    private static final int COLOR_ALERT = 0xFFFF6B3D;
    private static final int COLOR_WHITEOUT = 0xFFFFF8E8;
    private static final int COLOR_HEAT = 0xFFFFA23C;
    private static final int COLOR_SOOT = 0xFF140804;
    private static final int COLOR_GHOST = 0xFFF2F2F2;
    private static final int COLOR_GHOST_DARK = 0xFF050505;

    private static int countdownTicks;
    private static int detonationTicks;
    private static int heavyShakeTicks;
    private static int rumbleTicks;
    private static int hauntShakeTicks;
    private static int hauntBlinkTicks;
    private static int hauntFlashTicks;
    private static int nextBlinkTicks;
    private static int nextSoundTicks;
    private static int nextShakeTicks;
    private static int hauntLifetimeTicks;
    private static boolean hauntingActive;
    private static boolean detonationPlayed;
    private static boolean alarmPlayed;
    private static boolean releaseMessageShown;
    private static float lastYawOffset;
    private static float lastPitchOffset;

    private ClientNukeEffect() {
    }

    public static boolean trigger(class_310 minecraft) {
        if (minecraft == null || minecraft.field_1724 == null) {
            return false;
        }

        clearState(minecraft);
        countdownTicks = COUNTDOWN_TICKS;
        minecraft.method_1507(null);
        minecraft.field_1724.method_7353(class_2561.method_43471("message.pvcfinder.nuke_client"), true);
        return true;
    }

    public static void tick(class_310 minecraft) {
        if (minecraft == null || minecraft.field_1724 == null || minecraft.field_1687 == null) {
            clearState(minecraft);
            return;
        }

        if (countdownTicks > 0) {
            if (!alarmPlayed) {
                minecraft.method_1483().method_4873(class_1109.method_4757(NUCLEAR_ALARM_EVENT, 1.0F, 1.0F));
                alarmPlayed = true;
            }
            countdownTicks--;
            if (countdownTicks == 0) {
                detonationTicks = DETONATION_TICKS;
                heavyShakeTicks = HEAVY_SHAKE_TICKS;
                rumbleTicks = RUMBLE_TICKS;
                hauntingActive = true;
                hauntLifetimeTicks = 0;
                scheduleHauntEvents();
            }
        } else if (detonationTicks > 0) {
            detonationTicks--;
            if (!detonationPlayed) {
                minecraft.method_1483().method_4873(class_1109.method_4757(class_3417.field_38830, 2.0F, 0.48F));
                minecraft.method_1483().method_4873(class_1109.method_4757(class_3417.field_14865, 3.2F, 0.45F));
                minecraft.method_1483().method_4873(class_1109.method_4757(class_3417.field_14803, 2.8F, 0.42F));
                detonationPlayed = true;
            }
            if (detonationTicks == 0 && !releaseMessageShown) {
                minecraft.field_1724.method_7353(class_2561.method_43471("message.pvcfinder.nuke_released"), true);
                releaseMessageShown = true;
            }
        }

        if (hauntingActive) {
            tickHaunting(minecraft);
        }

        tickCamera(minecraft);
    }

    public static void renderOverlay(class_310 minecraft, class_332 guiGraphics) {
        if (minecraft == null || guiGraphics == null) {
            return;
        }

        int width = minecraft.method_22683().method_4486();
        int height = minecraft.method_22683().method_4502();
        if (countdownTicks > 0) {
            renderCountdown(guiGraphics, minecraft, width, height);
        }
        if (detonationTicks > 0) {
            renderDetonation(guiGraphics, width, height);
        }
        if (hauntingActive) {
            renderHauntingOverlay(guiGraphics, width, height);
        }
    }

    private static void tickHaunting(class_310 minecraft) {
        hauntLifetimeTicks++;

        if (hauntBlinkTicks > 0) {
            hauntBlinkTicks--;
        }
        if (hauntFlashTicks > 0) {
            hauntFlashTicks--;
        }
        if (hauntShakeTicks > 0) {
            hauntShakeTicks--;
        }

        if (--nextBlinkTicks <= 0) {
            hauntBlinkTicks = 4 + RANDOM.nextInt(4);
            hauntFlashTicks = Math.max(hauntFlashTicks, 2 + RANDOM.nextInt(3));
            nextBlinkTicks = randomRange(120, 280);
        }

        if (--nextShakeTicks <= 0) {
            hauntShakeTicks = randomRange(18, 46);
            rumbleTicks = Math.max(rumbleTicks, randomRange(22, 48));
            nextShakeTicks = randomRange(100, 240);
        }

        if (--nextSoundTicks <= 0) {
            playHauntSound(minecraft);
            nextSoundTicks = randomRange(140, 320);
        }
    }

    private static void renderCountdown(class_332 guiGraphics, class_310 minecraft, int width, int height) {
        float progress = 1.0F - (countdownTicks / (float) COUNTDOWN_TICKS);
        float pulse = 0.04F + ((float) Math.sin((COUNTDOWN_TICKS - countdownTicks) * 0.18F) * 0.02F);
        float urgent = countdownTicks <= 100 ? (1.0F - (countdownTicks / 100.0F)) : 0.0F;
        int seconds = class_3532.method_15386(countdownTicks / 20.0F);
        String timerText = String.format("%02d", seconds);

        guiGraphics.method_25294(0, 0, width, 30, withAlpha(COLOR_SOOT, 0.8F));
        guiGraphics.method_25294(0, 30, width, 32, withAlpha(COLOR_ALERT, 0.6F + (urgent * 0.3F)));
        guiGraphics.method_25294(0, 0, width, height, withAlpha(COLOR_ALERT, pulse + (urgent * 0.05F)));
        guiGraphics.method_51433(font(minecraft), "LOOK FOR REFUGE", 12, 10, withAlpha(COLOR_WARNING, 0.9F + (urgent * 0.1F)), false);
        guiGraphics.method_51433(font(minecraft), timerText, width - font(minecraft).method_1727(timerText) - 14, 10, withAlpha(COLOR_WHITEOUT, 0.98F), false);

        int barLeft = 12;
        int barRight = width - 12;
        int barTop = 36;
        int filled = barLeft + Math.round((barRight - barLeft) * progress);
        guiGraphics.method_25294(barLeft, barTop, barRight, barTop + 5, withAlpha(0xFF2A1109, 0.82F));
        guiGraphics.method_25294(barLeft, barTop, filled, barTop + 5, withAlpha(COLOR_ALERT, 0.96F));
    }

    private static void renderDetonation(class_332 guiGraphics, int width, int height) {
        int elapsed = DETONATION_TICKS - detonationTicks;
        float progress = detonationTicks / (float) DETONATION_TICKS;
        float whiteout = elapsed < 44
                ? 1.0F
                : class_3532.method_15363((progress * progress * 2.2F) + 0.3F, 0.0F, 1.0F);
        float heat = class_3532.method_15363((progress * 1.1F) + 0.22F, 0.0F, 1.0F);
        float soot = class_3532.method_15363((1.0F - progress) * 0.74F, 0.0F, 0.74F);
        float bloom = elapsed < 86 ? (1.0F - (elapsed / 86.0F)) : 0.0F;

        guiGraphics.method_25294(0, 0, width, height, withAlpha(COLOR_WHITEOUT, whiteout));
        guiGraphics.method_25294(0, 0, width, height, withAlpha(COLOR_HEAT, heat * 0.62F));
        guiGraphics.method_25294(0, 0, width, height / 2, withAlpha(COLOR_ALERT, bloom * 0.5F));
        guiGraphics.method_25294(0, 0, width, height, withAlpha(COLOR_ALERT, bloom * 0.18F));
        guiGraphics.method_25294(0, (height * 2) / 3, width, height, withAlpha(COLOR_SOOT, soot));
        guiGraphics.method_25294(0, 0, width, height, withAlpha(COLOR_SOOT, soot * 0.5F));
    }

    private static void renderHauntingOverlay(class_332 guiGraphics, int width, int height) {
        float pulse = 0.08F + (((float) Math.sin(hauntLifetimeTicks * 0.08F) + 1.0F) * 0.03F);
        guiGraphics.method_25294(0, 0, width, height, withAlpha(COLOR_SOOT, pulse));

        int vignetteAlpha = withAlpha(COLOR_SOOT, 0.22F);
        guiGraphics.method_25294(0, 0, width, 18, vignetteAlpha);
        guiGraphics.method_25294(0, height - 18, width, height, vignetteAlpha);
        guiGraphics.method_25294(0, 0, 12, height, vignetteAlpha);
        guiGraphics.method_25294(width - 12, 0, width, height, vignetteAlpha);

        if (hauntFlashTicks > 0) {
            float flash = 0.18F + (hauntFlashTicks / 5.0F) * 0.38F;
            guiGraphics.method_25294(0, 0, width, height, withAlpha(COLOR_WHITEOUT, flash));
        }

        if (hauntBlinkTicks > 0) {
            renderHerobrineBlink(guiGraphics, width, height);
        }
    }

    private static void renderHerobrineBlink(class_332 guiGraphics, int width, int height) {
        float alpha = class_3532.method_15363(hauntBlinkTicks / 6.0F, 0.0F, 1.0F);
        int centerX = width / 2;
        int centerY = height / 2;
        int jitterX = class_3532.method_15375(((float) Math.sin(hauntLifetimeTicks * 0.9F) * 5.0F) + (RANDOM.nextFloat() - 0.5F) * 4.0F);
        int jitterY = class_3532.method_15375(((float) Math.cos(hauntLifetimeTicks * 0.7F) * 4.0F));
        int headSize = Math.max(42, Math.min(width, height) / 4);
        int bodyWidth = Math.max(34, headSize / 2);
        int bodyHeight = Math.max(74, headSize + 18);
        int headLeft = centerX - (headSize / 2) + jitterX;
        int headTop = centerY - headSize + jitterY;
        int headRight = headLeft + headSize;
        int headBottom = headTop + headSize;
        int bodyLeft = centerX - (bodyWidth / 2) + jitterX;
        int bodyTop = headBottom - 4;
        int bodyRight = bodyLeft + bodyWidth;
        int bodyBottom = bodyTop + bodyHeight;
        int eyeWidth = Math.max(10, headSize / 5);
        int eyeHeight = Math.max(7, headSize / 7);
        int eyeY = headTop + Math.max(12, headSize / 3);
        int leftEyeX = headLeft + Math.max(10, headSize / 5);
        int rightEyeX = headRight - Math.max(10, headSize / 5) - eyeWidth;

        guiGraphics.method_25294(0, 0, width, height, withAlpha(COLOR_SOOT, 0.26F * alpha));
        guiGraphics.method_25294(headLeft - 8, headTop - 8, headRight + 8, bodyBottom + 10, withAlpha(COLOR_GHOST_DARK, 0.35F * alpha));
        guiGraphics.method_25294(headLeft, headTop, headRight, headBottom, withAlpha(0xFF141414, 0.96F * alpha));
        guiGraphics.method_25294(bodyLeft, bodyTop, bodyRight, bodyBottom, withAlpha(0xFF0D0D0D, 0.9F * alpha));
        guiGraphics.method_25294(bodyLeft - 20, bodyTop + 10, bodyLeft - 6, bodyTop + 54, withAlpha(0xFF0D0D0D, 0.8F * alpha));
        guiGraphics.method_25294(bodyRight + 6, bodyTop + 10, bodyRight + 20, bodyTop + 54, withAlpha(0xFF0D0D0D, 0.8F * alpha));
        guiGraphics.method_25294(leftEyeX, eyeY, leftEyeX + eyeWidth, eyeY + eyeHeight, withAlpha(COLOR_GHOST, alpha));
        guiGraphics.method_25294(rightEyeX, eyeY, rightEyeX + eyeWidth, eyeY + eyeHeight, withAlpha(COLOR_GHOST, alpha));
        guiGraphics.method_25294(leftEyeX - 3, eyeY - 3, leftEyeX + eyeWidth + 3, eyeY + eyeHeight + 3, withAlpha(COLOR_WHITEOUT, 0.14F * alpha));
        guiGraphics.method_25294(rightEyeX - 3, eyeY - 3, rightEyeX + eyeWidth + 3, eyeY + eyeHeight + 3, withAlpha(COLOR_WHITEOUT, 0.14F * alpha));
    }

    private static void tickCamera(class_310 minecraft) {
        restoreCamera(minecraft);
        if (minecraft.field_1724 == null) {
            return;
        }

        int activeTicks = Math.max(heavyShakeTicks, Math.max(hauntShakeTicks, rumbleTicks));
        if (activeTicks <= 0) {
            return;
        }

        float maxTicks;
        float amplitude;
        if (heavyShakeTicks > 0) {
            maxTicks = HEAVY_SHAKE_TICKS;
            float progress = heavyShakeTicks / maxTicks;
            amplitude = 28.0F * progress * progress;
            heavyShakeTicks--;
        } else if (hauntShakeTicks > 0) {
            maxTicks = 46.0F;
            float progress = hauntShakeTicks / maxTicks;
            amplitude = 12.0F * (0.55F + progress);
            hauntShakeTicks--;
        } else {
            maxTicks = RUMBLE_TICKS;
            float progress = rumbleTicks / maxTicks;
            amplitude = 8.5F * Math.max(progress, 0.32F);
            rumbleTicks--;
        }

        lastYawOffset = (RANDOM.nextFloat() - 0.5F) * amplitude;
        lastPitchOffset = (RANDOM.nextFloat() - 0.5F) * amplitude * 0.82F;
        minecraft.field_1724.method_36456(minecraft.field_1724.method_36454() + lastYawOffset);
        minecraft.field_1724.method_36457(class_3532.method_15363(minecraft.field_1724.method_36455() + lastPitchOffset, -90.0F, 90.0F));
    }

    private static void playHauntSound(class_310 minecraft) {
        float volume = 0.7F + (RANDOM.nextFloat() * 0.7F);
        float pitch = 0.55F + (RANDOM.nextFloat() * 0.45F);
        class_3414 sound = switch (RANDOM.nextInt(4)) {
            case 0 -> class_3417.field_14967;
            case 1 -> class_3417.field_14802;
            case 2 -> class_3417.field_15045;
            default -> class_3417.field_23118;
        };
        minecraft.method_1483().method_4873(class_1109.method_4757(sound, volume, pitch));
    }

    private static void scheduleHauntEvents() {
        nextBlinkTicks = randomRange(7_200, 9_600);
        nextSoundTicks = randomRange(6_600, 10_200);
        nextShakeTicks = randomRange(6_800, 9_800);
        hauntBlinkTicks = 0;
        hauntFlashTicks = 0;
        hauntShakeTicks = 0;
    }

    private static int randomRange(int minInclusive, int maxInclusive) {
        return minInclusive + RANDOM.nextInt((maxInclusive - minInclusive) + 1);
    }

    private static void restoreCamera(class_310 minecraft) {
        if (minecraft == null || minecraft.field_1724 == null) {
            lastYawOffset = 0.0F;
            lastPitchOffset = 0.0F;
            return;
        }
        if (lastYawOffset == 0.0F && lastPitchOffset == 0.0F) {
            return;
        }

        minecraft.field_1724.method_36456(minecraft.field_1724.method_36454() - lastYawOffset);
        minecraft.field_1724.method_36457(class_3532.method_15363(minecraft.field_1724.method_36455() - lastPitchOffset, -90.0F, 90.0F));
        lastYawOffset = 0.0F;
        lastPitchOffset = 0.0F;
    }

    private static void clearState(class_310 minecraft) {
        restoreCamera(minecraft);
        countdownTicks = 0;
        detonationTicks = 0;
        heavyShakeTicks = 0;
        rumbleTicks = 0;
        hauntShakeTicks = 0;
        hauntBlinkTicks = 0;
        hauntFlashTicks = 0;
        nextBlinkTicks = 0;
        nextSoundTicks = 0;
        nextShakeTicks = 0;
        hauntLifetimeTicks = 0;
        hauntingActive = false;
        detonationPlayed = false;
        alarmPlayed = false;
        releaseMessageShown = false;
    }

    private static net.minecraft.class_327 font(class_310 minecraft) {
        return minecraft.field_1772;
    }

    private static int withAlpha(int color, float factor) {
        int alpha = (color >>> 24) & 0xFF;
        int red = (color >>> 16) & 0xFF;
        int green = (color >>> 8) & 0xFF;
        int blue = color & 0xFF;
        int scaledAlpha = class_3532.method_15340(Math.round(alpha * factor), 0, 255);
        return (scaledAlpha << 24) | (red << 16) | (green << 8) | blue;
    }
}
