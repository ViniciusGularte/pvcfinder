package club.peacefulvanilla.pvcfinder.client;

import club.peacefulvanilla.pvcfinder.PvcFinderMod;
import club.peacefulvanilla.pvcfinder.data.PvcOffer;
import java.util.Comparator;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.class_10799;
import net.minecraft.class_11909;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_3532;
import net.minecraft.class_364;
import net.minecraft.class_4185;
import net.minecraft.class_4265;
import net.minecraft.class_437;
import net.minecraft.class_6379;

public final class PvcFinderScreen extends class_437 {
    private static final class_2960 LOGO_TEXTURE =
            class_2960.method_60655(PvcFinderMod.MOD_ID, "textures/gui/pvc_logo.png");
    private static final int LOGO_TEXTURE_WIDTH = 1890;
    private static final int LOGO_TEXTURE_HEIGHT = 1630;
    private static final int COLOR_BACKDROP = 0xD9080604;
    private static final int COLOR_BACKDROP_TOP = 0xCC140D08;
    private static final int COLOR_PANEL = 0xEE0F0B08;
    private static final int COLOR_PANEL_ALT = 0xE61A1209;
    private static final int COLOR_SECTION = 0xCC241810;
    private static final int COLOR_SECTION_SOFT = 0xC616100B;
    private static final int COLOR_BORDER = 0xFF7B4B25;
    private static final int COLOR_ACCENT = 0xFFE8760A;
    private static final int COLOR_ACCENT_DIM = 0xFFB85A00;
    private static final int COLOR_EMERALD = 0xFF4ADE80;
    private static final int COLOR_DIAMOND = 0xFF67E8F9;
    private static final int COLOR_TEXT_BRIGHT = 0xFFF5F0E8;
    private static final int COLOR_TEXT = 0xFFD8CCBC;
    private static final int COLOR_TEXT_MUTED = 0xFFBCAE9C;
    private static final int COLOR_TEXT_GHOST = 0xFF8F7C6B;
    private static final int COLOR_DANGER = 0xFFE35C5C;
    private static final int TRACK_BUTTON_WIDTH = 72;
    private static final int CONTENTS_BUTTON_WIDTH = 62;
    private static final int ACTION_BUTTON_HEIGHT = 20;
    private static final int ACTION_BUTTON_GAP = 8;
    private static final int SUMMARY_PANEL_WIDTH = 150;
    private static final int CHIP_HEIGHT = 18;
    private static final int CHIP_GAP = 6;
    private static final int COMPACT_LAYOUT_WIDTH = 760;
    private static final int FILTER_ROW_PITCH = 24;

    private final PvcFinderDataStore dataStore;
    private class_342 searchBox;
    private OfferList offerList;
    private List<PvcFinderSuggestion> searchSuggestions = List.of();
    private String searchQuery = "";
    private PvcFinderFilters.SortMode sortMode = PvcFinderFilters.SortMode.RELEVANCE;
    private boolean inStockOnly = true;
    private boolean includeShulker = true;
    private PvcFinderFilters.SearchScope searchScope = PvcFinderFilters.SearchScope.ITEM;
    private PvcFinderFilters.TradeIntent tradeIntent = PvcFinderFilters.TradeIntent.BOTH;
    private boolean filtersExpanded;
    private boolean layoutInitialized;
    private PvcOffer activeContentsOffer;
    private int contentsScrollOffset;
    private long observedDataRevision = -1L;

    public PvcFinderScreen(PvcFinderDataStore dataStore) {
        super(class_2561.method_43471("screen.pvcfinder.title"));
        this.dataStore = dataStore;
    }

    @Override
    protected void method_25426() {
        dataStore.ensureLoaded(field_22787);
        observedDataRevision = dataStore.revision();
        if (!layoutInitialized) {
            filtersExpanded = false;
            layoutInitialized = true;
        }

        int left = panelLeft();
        int contentWidth = panelWidth();
        searchBox = new class_342(field_22793, left + 22, searchBoxY(), contentWidth - 44, 18, class_2561.method_43471("screen.pvcfinder.search"));
        searchBox.method_1880(120);
        searchBox.method_1858(false);
        searchBox.method_1868(COLOR_TEXT_BRIGHT);
        searchBox.method_1860(COLOR_TEXT_MUTED);
        searchBox.method_1852(searchQuery);
        searchBox.method_1863(value -> {
            searchQuery = value;
            refreshSuggestions();
            refreshList();
        });
        method_37063(searchBox);

        offerList = method_37063(new OfferList(
                field_22787,
                field_22789,
                field_22790 - 20,
                listStartY(),
                offerRowHeight()
        ));
        method_48265(searchBox);
        refreshList();
    }

    @Override
    public void method_25410(class_310 minecraft, int width, int height) {
        searchQuery = searchBox == null ? searchQuery : searchBox.method_1882();
        super.method_25410(minecraft, width, height);
        if (searchBox != null) {
            searchBox.method_1852(searchQuery);
        }
    }

    @Override
    public boolean method_25402(class_11909 event, boolean doubleClick) {
        if (activeContentsOffer != null) {
            return handleContentsOverlayClick(event.comp_4798(), event.comp_4799(), event.method_74245());
        }
        if (event.method_74245() == 0 && focusSearchIfClicked(event.comp_4798(), event.comp_4799(), event, doubleClick)) {
            return true;
        }
        if (event.method_74245() == 0 && handleSuggestionClick(event.comp_4798(), event.comp_4799())) {
            return true;
        }
        if (event.method_74245() == 0 && handleHeaderClick(event.comp_4798(), event.comp_4799())) {
            blurSearchIfNeeded(event.comp_4798(), event.comp_4799());
            return true;
        }
        blurSearchIfNeeded(event.comp_4798(), event.comp_4799());
        return super.method_25402(event, doubleClick);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (activeContentsOffer != null) {
            return handleContentsOverlayScroll(mouseX, mouseY, scrollY);
        }
        return super.method_25401(mouseX, mouseY, scrollX, scrollY);
    }

    @Override
    public boolean method_25404(net.minecraft.class_11908 event) {
        if (activeContentsOffer != null && event.comp_4795() == 256) {
            closeContentsPreview();
            return true;
        }
        return super.method_25404(event);
    }

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        if (dataStore.revision() != observedDataRevision) {
            observedDataRevision = dataStore.revision();
            refreshList();
        }

        guiGraphics.method_25294(0, 0, field_22789, field_22790, COLOR_BACKDROP);
        guiGraphics.method_25294(0, 0, field_22789, 58, COLOR_BACKDROP_TOP);
        guiGraphics.method_25294(0, 58, field_22789, field_22790, 0xC4100C08);

        int left = panelLeft();
        int right = left + panelWidth();
        int searchTop = searchSectionTop();
        guiGraphics.method_25294(left - 10, 18, right + 10, field_22790 - 18, COLOR_PANEL);
        guiGraphics.method_25294(left - 10, 18, right + 10, 21, COLOR_ACCENT);
        guiGraphics.method_25294(left + 14, searchTop, right - 14, searchTop + 24, COLOR_SECTION);
        guiGraphics.method_25294(left + 14, statsRowY() - 6, right - 14, listStartY() - 12, COLOR_SECTION_SOFT);
        guiGraphics.method_25294(left + 14, statsRowY() - 6, right - 14, statsRowY() - 3, COLOR_BORDER);
        guiGraphics.method_25294(left + 14, listStartY() - 8, right - 14, listStartY() - 6, COLOR_BORDER);

        renderHeader(guiGraphics, left, right);

        renderSearchSection(guiGraphics, left, right);
        renderTopRow(guiGraphics, mouseX, mouseY, left, right);
        if (filtersExpanded) {
            renderSortRow(guiGraphics, mouseX, mouseY, left);
            renderScopeRow(guiGraphics, mouseX, mouseY, left);
            renderTradeRow(guiGraphics, mouseX, mouseY, left);
            renderNukeRow(guiGraphics, mouseX, mouseY, left);
        }
        renderTrackingSection(guiGraphics, mouseX, mouseY, left, right);

        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
        renderSuggestions(guiGraphics, mouseX, mouseY, left, right);
        if (activeContentsOffer != null) {
            renderContentsOverlay(guiGraphics, mouseX, mouseY);
        }
        ClientNukeEffect.renderOverlay(field_22787, guiGraphics);

        int footerY = field_22790 - 30;
        if (dataStore.errorMessage() != null) {
            guiGraphics.method_27534(field_22793, class_2561.method_43469("screen.pvcfinder.error", dataStore.errorMessage()), field_22789 / 2, footerY, COLOR_DANGER);
        } else if (dataStore.refreshErrorMessage() != null) {
            guiGraphics.method_27534(field_22793, class_2561.method_43471("screen.pvcfinder.refresh_failed"), field_22789 / 2, footerY, COLOR_TEXT_MUTED);
        } else if (offerList != null && offerList.entryCount() == 0) {
            guiGraphics.method_27534(field_22793, class_2561.method_43471("screen.pvcfinder.empty"), field_22789 / 2, footerY, COLOR_TEXT_MUTED);
        }
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    private void renderHeader(class_332 guiGraphics, int left, int right) {
        int centerX = (left + right) / 2;
        int logoWidth = 22;
        int logoHeight = 18;
        int titleWidth = field_22793.method_27525(field_22785);
        int blockWidth = logoWidth + 6 + titleWidth;
        int logoX = centerX - (blockWidth / 2);
        int logoY = 27;
        int titleX = logoX + logoWidth + 6;
        int titleY = 31;
        guiGraphics.method_25290(class_10799.field_56883, LOGO_TEXTURE, logoX, logoY, 0.0F, 0.0F, logoWidth, logoHeight, LOGO_TEXTURE_WIDTH, LOGO_TEXTURE_HEIGHT);
        guiGraphics.method_51439(field_22793, field_22785, titleX, titleY, COLOR_TEXT_BRIGHT, false);
    }

    private void renderSearchSection(class_332 guiGraphics, int left, int right) {
        guiGraphics.method_25294(left + 18, searchSectionTop() + 3, right - 18, searchSectionTop() + 21, COLOR_PANEL_ALT);
        guiGraphics.method_25294(left + 18, searchSectionTop() + 4, right - 18, searchSectionTop() + 6, COLOR_ACCENT_DIM);
    }

    private void renderTopRow(class_332 guiGraphics, int mouseX, int mouseY, int left, int right) {
        int rowY = statsRowY();
        int controlsY = controlsRowY();
        drawStatChip(guiGraphics, left + 20, rowY, "OFFERS " + dataStore.offerCount(), COLOR_EMERALD, COLOR_PANEL_ALT, 92);
        drawStatChip(guiGraphics, left + 124, rowY, "RESULTS " + (offerList == null ? 0 : offerList.entryCount()), COLOR_ACCENT, COLOR_PANEL_ALT, 102);
        int filterX = filterChipX(right);
        int refreshX = refreshChipX(right);
        if (!isCompactLayout()) {
            int statusX = left + 238;
            int statusMaxWidth = refreshX - statusX - 10;
            if (statusMaxWidth >= 72) {
                renderMarketStatusChip(guiGraphics, statusX, rowY, statusMaxWidth, dataStore.marketStatusLabel(), marketStatusAccent(), COLOR_PANEL_ALT);
            }
        }
        renderChip(
                guiGraphics,
                mouseX,
                mouseY,
                refreshX,
                controlsY,
                refreshChipLabel(),
                dataStore.isRefreshing(),
                dataStore.isRefreshing() ? COLOR_DIAMOND : COLOR_EMERALD,
                false
        );
        renderChip(
                guiGraphics,
                mouseX,
                mouseY,
                filterX,
                controlsY,
                filtersExpanded ? "Hide filters" : "Show filters",
                filtersExpanded,
                COLOR_ACCENT,
                false
        );
    }

    private void renderSuggestions(class_332 guiGraphics, int mouseX, int mouseY, int left, int right) {
        if (!shouldRenderSuggestions()) {
            return;
        }

        int boxLeft = suggestionBoxLeft();
        int boxTop = suggestionBoxTop();
        int rowHeight = suggestionRowHeight();
        int boxRight = Math.min(boxLeft + suggestionBoxWidth(), right - 20);
        int boxBottom = boxTop + 4 + (searchSuggestions.size() * rowHeight) + 4;
        guiGraphics.method_25294(boxLeft, boxTop, boxRight, boxBottom, 0xF216100B);
        guiGraphics.method_25294(boxLeft, boxTop, boxLeft + 2, boxBottom, COLOR_ACCENT);
        guiGraphics.method_25294(boxLeft, boxTop, boxRight, boxTop + 1, COLOR_BORDER);
        guiGraphics.method_25294(boxLeft, boxBottom - 1, boxRight, boxBottom, COLOR_BORDER);

        for (int index = 0; index < searchSuggestions.size(); index++) {
            int rowTop = boxTop + 4 + (index * rowHeight);
            boolean hovered = isInside(mouseX, mouseY, boxLeft + 2, rowTop, (boxRight - boxLeft) - 4, rowHeight);
            if (hovered) {
                guiGraphics.method_25294(boxLeft + 4, rowTop, boxRight - 4, rowTop + rowHeight, 0x22000000);
            }
            PvcFinderSuggestion suggestion = searchSuggestions.get(index);
            guiGraphics.method_51433(field_22793, field_22793.method_27523(suggestion.label(), boxRight - boxLeft - 16), boxLeft + 8, rowTop + 3, COLOR_TEXT_BRIGHT, false);
        }
    }

    private void renderSortRow(class_332 guiGraphics, int mouseX, int mouseY, int left) {
        int y = sortRowY();
        drawFilterLabel(guiGraphics, "SORT", left + 20, y + 5);
        ChipFlow flow = new ChipFlow(left + 62, y, panelLeft() + panelWidth() - 24);
        for (PvcFinderFilters.SortMode option : PvcFinderFilters.SortMode.values()) {
            int chipX = flow.place(chipWidth(option.label(), false));
            renderChip(guiGraphics, mouseX, mouseY, chipX, flow.y, option.label(), sortMode == option, COLOR_ACCENT, false);
            flow.advance(chipWidth(option.label(), false));
        }
    }

    private void renderScopeRow(class_332 guiGraphics, int mouseX, int mouseY, int left) {
        int y = scopeRowY();
        drawFilterLabel(guiGraphics, "SEARCH", left + 20, y + 5);
        ChipFlow flow = new ChipFlow(left + 74, y, panelLeft() + panelWidth() - 24);
        for (PvcFinderFilters.SearchScope option : PvcFinderFilters.SearchScope.values()) {
            int chipX = flow.place(chipWidth(option.label(), false));
            renderChip(guiGraphics, mouseX, mouseY, chipX, flow.y, option.label(), searchScope == option, COLOR_DIAMOND, false);
            flow.advance(chipWidth(option.label(), false));
        }
    }

    private void renderTradeRow(class_332 guiGraphics, int mouseX, int mouseY, int left) {
        int y = tradeRowY();
        drawFilterLabel(guiGraphics, "TRADE", left + 20, y + 5);
        ChipFlow flow = new ChipFlow(left + 68, y, panelLeft() + panelWidth() - 24);
        for (PvcFinderFilters.TradeIntent option : PvcFinderFilters.TradeIntent.values()) {
            int chipWidth = chipWidth(option.label(), false);
            int chipX = flow.place(chipWidth);
            renderChip(guiGraphics, mouseX, mouseY, chipX, flow.y, option.label(), tradeIntent == option, COLOR_EMERALD, false);
            flow.advance(chipWidth);
        }

        int spacerWidth = 16;
        flow.advance(spacerWidth - CHIP_GAP);
        String inStockLabel = class_2561.method_43471("screen.pvcfinder.filter_in_stock").getString();
        int inStockWidth = chipWidth(inStockLabel, true);
        int inStockX = flow.place(inStockWidth);
        renderChip(guiGraphics, mouseX, mouseY, inStockX, flow.y, inStockLabel, inStockOnly, COLOR_EMERALD, true);
        flow.advance(inStockWidth);
        String shulkerLabel = class_2561.method_43471("screen.pvcfinder.filter_shulker").getString();
        int shulkerWidth = chipWidth(shulkerLabel, true);
        int shulkerX = flow.place(shulkerWidth);
        renderChip(guiGraphics, mouseX, mouseY, shulkerX, flow.y, shulkerLabel, includeShulker, COLOR_ACCENT, true);
        flow.advance(shulkerWidth);
    }

    private void renderNukeRow(class_332 guiGraphics, int mouseX, int mouseY, int left) {
        int y = nukeRowY();
        drawFilterLabel(guiGraphics, "FRIEND", left + 20, y + 5);
        renderChip(
                guiGraphics,
                mouseX,
                mouseY,
                left + 68,
                y,
                partyChipLabel(),
                PvcFinderClient.isImaginaryFriendActive(),
                COLOR_DIAMOND,
                false
        );
    }

    private void renderTrackingSection(class_332 guiGraphics, int mouseX, int mouseY, int left, int right) {
        int y = trackingSectionY();
        guiGraphics.method_25294(left + 20, y, right - 20, y + 24, COLOR_PANEL_ALT);
        guiGraphics.method_25294(left + 20, y, right - 20, y + 2, COLOR_BORDER);
        guiGraphics.method_51433(field_22793, "TRACKED", left + 28, y + 8, COLOR_TEXT_GHOST, false);

        TrackedShopTarget trackedTarget = PvcFinderClient.trackedTarget();
        if (trackedTarget == null) {
            guiGraphics.method_51433(field_22793, "No active target", left + 88, y + 8, COLOR_TEXT_MUTED, false);
            return;
        }

        String summary = trackedTarget.label() + "  |  " + trackedTarget.position().method_10263() + ", " + trackedTarget.position().method_10264() + ", " + trackedTarget.position().method_10260();
        String stopLabel = class_2561.method_43471("screen.pvcfinder.stop_tracking").getString();
        int stopWidth = chipWidth(stopLabel, false);
        int stopX = right - stopWidth - 24;
        drawTrimmed(guiGraphics, summary, left + 88, y + 8, stopX - left - 100, COLOR_TEXT_BRIGHT);
        renderChip(
                guiGraphics,
                mouseX,
                mouseY,
                stopX,
                y + 3,
                stopLabel,
                true,
                COLOR_DANGER,
                false
        );
    }

    private boolean handleHeaderClick(double mouseX, double mouseY) {
        int left = panelLeft();
        int right = panelLeft() + panelWidth();
        int refreshWidth = chipWidth(refreshChipLabel(), false);
        if (isInside(mouseX, mouseY, refreshChipX(right), controlsRowY(), refreshWidth, CHIP_HEIGHT)) {
            dataStore.refreshAsync(field_22787, true);
            return true;
        }

        int toggleWidth = chipWidth(filtersExpanded ? "Hide filters" : "Show filters", false);
        if (isInside(mouseX, mouseY, filterChipX(right), controlsRowY(), toggleWidth, CHIP_HEIGHT)) {
            searchQuery = searchBox == null ? searchQuery : searchBox.method_1882();
            filtersExpanded = !filtersExpanded;
            method_41843();
            return true;
        }

        if (!filtersExpanded) {
            return handleTrackingActionClick(mouseX, mouseY, right);
        }

        int y = sortRowY();
        ChipFlow flow = new ChipFlow(left + 62, y, panelLeft() + panelWidth() - 24);
        for (PvcFinderFilters.SortMode option : PvcFinderFilters.SortMode.values()) {
            int width = chipWidth(option.label(), false);
            int chipX = flow.place(width);
            if (isInside(mouseX, mouseY, chipX, flow.y, width, CHIP_HEIGHT)) {
                sortMode = option;
                refreshList();
                return true;
            }
            flow.advance(width);
        }

        y = scopeRowY();
        flow = new ChipFlow(left + 74, y, panelLeft() + panelWidth() - 24);
        for (PvcFinderFilters.SearchScope option : PvcFinderFilters.SearchScope.values()) {
            int width = chipWidth(option.label(), false);
            int chipX = flow.place(width);
            if (isInside(mouseX, mouseY, chipX, flow.y, width, CHIP_HEIGHT)) {
                searchScope = option;
                refreshList();
                return true;
            }
            flow.advance(width);
        }

        y = tradeRowY();
        flow = new ChipFlow(left + 68, y, panelLeft() + panelWidth() - 24);
        for (PvcFinderFilters.TradeIntent option : PvcFinderFilters.TradeIntent.values()) {
            int width = chipWidth(option.label(), false);
            int chipX = flow.place(width);
            if (isInside(mouseX, mouseY, chipX, flow.y, width, CHIP_HEIGHT)) {
                tradeIntent = option;
                refreshList();
                return true;
            }
            flow.advance(width);
        }

        String inStockLabel = class_2561.method_43471("screen.pvcfinder.filter_in_stock").getString();
        int inStockWidth = chipWidth(inStockLabel, true);
        flow.advance(16 - CHIP_GAP);
        int inStockX = flow.place(inStockWidth);
        if (isInside(mouseX, mouseY, inStockX, flow.y, inStockWidth, CHIP_HEIGHT)) {
            inStockOnly = !inStockOnly;
            refreshList();
            return true;
        }
        flow.advance(inStockWidth);

        String shulkerLabel = class_2561.method_43471("screen.pvcfinder.filter_shulker").getString();
        int shulkerWidth = chipWidth(shulkerLabel, true);
        int shulkerX = flow.place(shulkerWidth);
        if (isInside(mouseX, mouseY, shulkerX, flow.y, shulkerWidth, CHIP_HEIGHT)) {
            includeShulker = !includeShulker;
            refreshList();
            return true;
        }

        int partyX = left + 68;
        int partyY = nukeRowY();
        int partyWidth = chipWidth(partyChipLabel(), false);
        if (isInside(mouseX, mouseY, partyX, partyY, partyWidth, CHIP_HEIGHT)) {
            PvcFinderClient.toggleImaginaryFriend(field_22787);
            return true;
        }

        return handleTrackingActionClick(mouseX, mouseY, right);
    }

    private boolean handleSuggestionClick(double mouseX, double mouseY) {
        if (!shouldRenderSuggestions()) {
            return false;
        }

        int left = suggestionBoxLeft();
        int top = suggestionBoxTop() + 4;
        int rowHeight = suggestionRowHeight();
        int width = suggestionBoxWidth();
        for (int index = 0; index < searchSuggestions.size(); index++) {
            int rowTop = top + (index * rowHeight);
            if (isInside(mouseX, mouseY, left, rowTop, width, rowHeight)) {
                searchQuery = searchSuggestions.get(index).label();
                searchBox.method_1852(searchQuery);
                searchBox.method_25365(false);
                searchSuggestions = List.of();
                return true;
            }
        }
        return false;
    }

    private void refreshList() {
        if (offerList == null) {
            return;
        }

        List<OfferEntry> entries = dataStore.filterOffers(currentFilters())
                .stream()
                .sorted(Comparator.comparing((PvcOffer offer) -> !PvcFinderClient.isTracked(offer)))
                .map(OfferEntry::new)
                .toList();
        offerList.method_25314(entries);
        refreshSuggestions();
    }

    private void refreshSuggestions() {
        if (dataStore == null) {
            return;
        }
        searchSuggestions = dataStore.suggestions(currentFilters(), 3);
    }

    private void openContentsPreview(PvcOffer offer) {
        activeContentsOffer = offer;
        contentsScrollOffset = 0;
    }

    private void closeContentsPreview() {
        activeContentsOffer = null;
        contentsScrollOffset = 0;
    }


    private void renderContentsOverlay(class_332 guiGraphics, int mouseX, int mouseY) {
        int modalLeft = contentsModalLeft();
        int modalTop = contentsModalTop();
        int modalRight = modalLeft + contentsModalWidth();
        int modalBottom = modalTop + contentsModalHeight();
        int bodyLeft = contentsBodyLeft();
        int bodyTop = contentsBodyTop();
        int bodyRight = contentsBodyRight();
        int bodyBottom = contentsBodyBottom();
        int closeWidth = contentsCloseButtonWidth();
        guiGraphics.method_25294(0, 0, field_22789, field_22790, 0xA0000000);
        guiGraphics.method_25294(modalLeft, modalTop, modalRight, modalBottom, COLOR_PANEL);
        guiGraphics.method_25294(modalLeft, modalTop, modalRight, modalTop + 2, COLOR_ACCENT);
        guiGraphics.method_25294(modalLeft + 14, bodyTop - 6, modalRight - 14, bodyBottom + 10, COLOR_SECTION_SOFT);
        guiGraphics.method_51439(field_22793, class_2561.method_43471("screen.pvcfinder.contents"), modalLeft + 16, modalTop + 14, COLOR_TEXT_BRIGHT, false);
        drawTrimmed(guiGraphics, activeContentsOffer.title(), modalLeft + 16, modalTop + 30, 220, COLOR_TEXT_MUTED);
        renderChip(
                guiGraphics,
                mouseX,
                mouseY,
                modalRight - closeWidth - 16,
                modalTop + 12,
                class_2561.method_43471("screen.pvcfinder.close").getString(),
                false,
                COLOR_BORDER,
                false
        );

        guiGraphics.method_25294(bodyLeft, bodyTop, bodyRight, bodyBottom, COLOR_PANEL_ALT);
        guiGraphics.method_25294(bodyLeft, bodyTop, bodyRight, bodyTop + 2, COLOR_DIAMOND);
        guiGraphics.method_51433(field_22793, "Trade preview", bodyLeft + 12, bodyTop + 8, COLOR_TEXT_GHOST, false);
        drawTrimmed(guiGraphics, "Scroll to inspect every shulker involved in this trade.", bodyLeft + 12, bodyTop + 20, bodyRight - bodyLeft - 34, COLOR_TEXT_MUTED);

        List<String> lines = activeContentsOffer.previewContents();
        int visibleLines = contentsVisibleLines();
        int fromIndex = class_3532.method_15340(contentsScrollOffset, 0, contentsMaxScroll());
        int toIndex = Math.min(lines.size(), fromIndex + visibleLines);
        int y = bodyTop + 40;
        for (int index = fromIndex; index < toIndex; index++) {
            String line = lines.get(index);
            int rowTop = y;
            int rowBottom = rowTop + 12;
            if (!line.isBlank() && ((index - fromIndex) & 1) == 0) {
                guiGraphics.method_25294(bodyLeft + 8, rowTop - 1, bodyRight - 18, rowBottom + 1, 0x14000000);
            }
            if (!line.isBlank()) {
                boolean sectionLine = !line.startsWith("  ");
                drawTrimmed(
                        guiGraphics,
                        line.stripLeading(),
                        bodyLeft + 12,
                        rowTop + 1,
                        bodyRight - bodyLeft - 36,
                        sectionLine ? COLOR_DIAMOND : COLOR_TEXT
                );
            }
            y += 13;
        }

        if (fromIndex > 0) {
            guiGraphics.method_25300(field_22793, "^ more ^", (bodyLeft + bodyRight) / 2, bodyTop + 31, COLOR_TEXT_GHOST);
        }
        if (toIndex < lines.size()) {
            guiGraphics.method_25300(field_22793, "v more v", (bodyLeft + bodyRight) / 2, bodyBottom - 12, COLOR_TEXT_GHOST);
        }

        renderContentsScrollbar(guiGraphics, lines.size(), visibleLines, fromIndex, bodyRight - 10, bodyTop + 40, bodyBottom - 12);
        drawTrimmed(guiGraphics, lines.size() + " lines", modalLeft + 18, modalBottom - 18, 90, COLOR_TEXT_GHOST);
        drawTrimmed(guiGraphics, "Mouse wheel scrolls the trade preview.", modalLeft + 88, modalBottom - 18, 180, COLOR_TEXT_MUTED);
    }

    private void renderContentsScrollbar(class_332 guiGraphics, int totalLines, int visibleLines, int offset, int x, int top, int bottom) {
        guiGraphics.method_25294(x, top, x + 4, bottom, 0x33000000);
        if (totalLines <= visibleLines) {
            guiGraphics.method_25294(x, top, x + 4, bottom, COLOR_BORDER);
            return;
        }

        int trackHeight = Math.max(16, bottom - top);
        int thumbHeight = Math.max(14, class_3532.method_15375((visibleLines / (float) totalLines) * trackHeight));
        int maxOffset = Math.max(1, totalLines - visibleLines);
        int thumbTravel = Math.max(1, trackHeight - thumbHeight);
        int thumbTop = top + class_3532.method_15375((offset / (float) maxOffset) * thumbTravel);
        guiGraphics.method_25294(x, thumbTop, x + 4, thumbTop + thumbHeight, COLOR_ACCENT);
    }

    private boolean handleContentsOverlayClick(double mouseX, double mouseY, int button) {
        if (button != 0) {
            return true;
        }

        if (!isInside(mouseX, mouseY, contentsModalLeft(), contentsModalTop(), contentsModalWidth(), contentsModalHeight())) {
            closeContentsPreview();
            return true;
        }

        int closeWidth = contentsCloseButtonWidth();
        int closeX = contentsModalLeft() + contentsModalWidth() - closeWidth - 16;
        int closeY = contentsModalTop() + 12;
        if (isInside(mouseX, mouseY, closeX, closeY, closeWidth, CHIP_HEIGHT)) {
            closeContentsPreview();
        }
        return true;
    }

    private boolean handleContentsOverlayScroll(double mouseX, double mouseY, double scrollY) {
        if (activeContentsOffer == null) {
            return false;
        }

        if (!isInside(mouseX, mouseY, contentsBodyLeft(), contentsBodyTop(), contentsBodyRight() - contentsBodyLeft(), contentsBodyBottom() - contentsBodyTop())) {
            return true;
        }

        int direction = scrollY > 0 ? -1 : (scrollY < 0 ? 1 : 0);
        if (direction == 0) {
            return true;
        }
        contentsScrollOffset = class_3532.method_15340(contentsScrollOffset + direction, 0, contentsMaxScroll());
        return true;
    }

    private int contentsModalWidth() {
        return 330;
    }

    private int contentsModalHeight() {
        return 212;
    }

    private int contentsModalLeft() {
        return (field_22789 / 2) - (contentsModalWidth() / 2);
    }

    private int contentsModalTop() {
        return (field_22790 / 2) - (contentsModalHeight() / 2);
    }

    private int contentsBodyLeft() {
        return contentsModalLeft() + 16;
    }

    private int contentsBodyTop() {
        return contentsModalTop() + 48;
    }

    private int contentsBodyRight() {
        return contentsModalLeft() + contentsModalWidth() - 16;
    }

    private int contentsBodyBottom() {
        return contentsModalTop() + contentsModalHeight() - 28;
    }

    private int contentsVisibleLines() {
        return Math.max(1, (contentsBodyBottom() - (contentsBodyTop() + 44)) / 13);
    }


    private int contentsMaxScroll() {
        if (activeContentsOffer == null) {
            return 0;
        }
        return Math.max(0, activeContentsOffer.previewContents().size() - contentsVisibleLines());
    }

    private int contentsCloseButtonWidth() {
        return chipWidth(class_2561.method_43471("screen.pvcfinder.close").getString(), false);
    }

    private PvcFinderFilters currentFilters() {
        return new PvcFinderFilters(
                searchQuery.trim(),
                sortMode,
                inStockOnly,
                includeShulker,
                searchScope,
                tradeIntent
        );
    }

    private int panelWidth() {
        return Math.max(360, field_22789 - 48);
    }

    private int panelLeft() {
        return (field_22789 - panelWidth()) / 2;
    }

    private int listStartY() {
        return trackingSectionY() + 24;
    }

    private int trackingSectionY() {
        return filtersExpanded ? (filtersStartY() + totalFiltersHeight()) : (controlsRowY() + 28);
    }

    private int searchSectionTop() {
        return 42;
    }

    private int searchBoxY() {
        return searchSectionTop() + 6;
    }

    private int statsRowY() {
        return 70;
    }

    private int controlsRowY() {
        return isCompactLayout() ? (statsRowY() + 22) : statsRowY();
    }

    private int filtersStartY() {
        return controlsRowY() + CHIP_HEIGHT + 10;
    }

    private int sortRowY() {
        return filtersStartY();
    }

    private int scopeRowY() {
        return sortRowY() + rowHeightFor(sortRowStartX(), this::sortChipWidths);
    }

    private int tradeRowY() {
        return scopeRowY() + rowHeightFor(scopeRowStartX(), this::scopeChipWidths);
    }

    private int nukeRowY() {
        return tradeRowY() + rowHeightFor(tradeRowStartX(), this::tradeChipWidths);
    }

    private int totalFiltersHeight() {
        return (nukeRowY() - filtersStartY()) + 24;
    }

    private int sortRowStartX() {
        return panelLeft() + 62;
    }

    private int scopeRowStartX() {
        return panelLeft() + 74;
    }

    private int tradeRowStartX() {
        return panelLeft() + 68;
    }

    private int rowHeightFor(int startX, Supplier<int[]> widthsSupplier) {
        int rows = wrappedRowCount(startX, widthsSupplier.get());
        return Math.max(1, rows) * FILTER_ROW_PITCH;
    }

    private int wrappedRowCount(int startX, int[] chipWidths) {
        int maxRight = panelLeft() + panelWidth() - 24;
        int x = startX;
        int rows = 1;
        for (int chipWidth : chipWidths) {
            if (x != startX && (x + chipWidth) > maxRight) {
                rows++;
                x = startX;
            }
            x += chipWidth + CHIP_GAP;
        }
        return rows;
    }

    private int[] sortChipWidths() {
        return java.util.Arrays.stream(PvcFinderFilters.SortMode.values())
                .mapToInt(option -> chipWidth(option.label(), false))
                .toArray();
    }

    private int[] scopeChipWidths() {
        return java.util.Arrays.stream(PvcFinderFilters.SearchScope.values())
                .mapToInt(option -> chipWidth(option.label(), false))
                .toArray();
    }

    private int[] tradeChipWidths() {
        String inStockLabel = class_2561.method_43471("screen.pvcfinder.filter_in_stock").getString();
        String shulkerLabel = class_2561.method_43471("screen.pvcfinder.filter_shulker").getString();
        int[] intentWidths = java.util.Arrays.stream(PvcFinderFilters.TradeIntent.values())
                .mapToInt(option -> chipWidth(option.label(), false))
                .toArray();
        int[] allWidths = new int[intentWidths.length + 3];
        System.arraycopy(intentWidths, 0, allWidths, 0, intentWidths.length);
        allWidths[intentWidths.length] = 16;
        allWidths[intentWidths.length + 1] = chipWidth(inStockLabel, true);
        allWidths[intentWidths.length + 2] = chipWidth(shulkerLabel, true);
        return allWidths;
    }

    private int suggestionBoxLeft() {
        return searchBox == null ? panelLeft() + 22 : searchBox.method_46426();
    }

    private int suggestionBoxTop() {
        return (searchBox == null ? searchBoxY() : searchBox.method_46427()) + 22;
    }

    private int suggestionBoxWidth() {
        int available = searchBox == null ? panelWidth() - 44 : searchBox.method_25368();
        return class_3532.method_15340(Math.min(available, 320), 210, 320);
    }

    private int suggestionRowHeight() {
        return 14;
    }

    private boolean isCompactLayout() {
        return panelWidth() <= COMPACT_LAYOUT_WIDTH;
    }

    private int offerRowHeight() {
        return isCompactLayout() ? 108 : 88;
    }

    private void drawFilterLabel(class_332 guiGraphics, String label, int x, int y) {
        guiGraphics.method_51433(field_22793, label, x, y, COLOR_TEXT_GHOST, false);
    }

    private String partyChipLabel() {
        return class_2561.method_43471(
                PvcFinderClient.isImaginaryFriendActive()
                        ? "screen.pvcfinder.hide_party"
                        : "screen.pvcfinder.spawn_party"
        ).getString();
    }

    private void drawStatChip(class_332 guiGraphics, int x, int y, String text, int accent, int background, int minWidth) {
        int chipWidth = Math.max(minWidth, field_22793.method_1727(text) + 14);
        guiGraphics.method_25294(x, y, x + chipWidth, y + 16, background);
        guiGraphics.method_25294(x, y, x + chipWidth, y + 2, accent);
        guiGraphics.method_51433(field_22793, text, x + 7, y + 5, COLOR_TEXT_BRIGHT, false);
    }

    private void renderMarketStatusChip(class_332 guiGraphics, int x, int y, int maxWidth, String text, int accent, int background) {
        int boundedMax = Math.max(24, maxWidth);
        int chipWidth = class_3532.method_15340(Math.max(72, field_22793.method_1727(text) + 14), 72, boundedMax);
        guiGraphics.method_25294(x, y, x + chipWidth, y + 16, background);
        guiGraphics.method_25294(x, y, x + chipWidth, y + 2, accent);
        guiGraphics.method_51433(field_22793, field_22793.method_27523(text, chipWidth - 14), x + 7, y + 5, COLOR_TEXT_BRIGHT, false);
    }

    private void renderChip(class_332 guiGraphics, int mouseX, int mouseY, int x, int y, String label, boolean active, int accent, boolean toggle) {
        int width = chipWidth(label, toggle);
        boolean hovered = isInside(mouseX, mouseY, x, y, width, CHIP_HEIGHT);
        int body = active ? 0xFF2A1A10 : COLOR_PANEL_ALT;
        if (hovered && !active) {
            body = 0xFF24160D;
        }

        guiGraphics.method_25294(x, y, x + width, y + CHIP_HEIGHT, body);
        guiGraphics.method_25294(x, y, x + width, y + 2, active ? accent : COLOR_BORDER);
        guiGraphics.method_25294(x, y, x + 1, y + CHIP_HEIGHT, COLOR_BORDER);
        guiGraphics.method_25294(x + width - 1, y, x + width, y + CHIP_HEIGHT, COLOR_BORDER);
        guiGraphics.method_25294(x, y + CHIP_HEIGHT - 1, x + width, y + CHIP_HEIGHT, COLOR_BORDER);

        int textX = x + 8;
        if (toggle) {
            guiGraphics.method_25294(x + 7, y + 5, x + 13, y + 11, active ? accent : COLOR_TEXT_GHOST);
            textX = x + 18;
        }
        guiGraphics.method_51433(field_22793, label, textX, y + 5, active ? COLOR_TEXT_BRIGHT : COLOR_TEXT, false);
    }

    private int chipWidth(String label, boolean toggle) {
        return field_22793.method_1727(label) + (toggle ? 28 : 16);
    }

    private String refreshChipLabel() {
        return dataStore.isRefreshing()
                ? class_2561.method_43471("screen.pvcfinder.refreshing").getString()
                : "Refresh";
    }

    private int filterChipX(int right) {
        return right - chipWidth(filtersExpanded ? "Hide filters" : "Show filters", false) - 22;
    }

    private int refreshChipX(int right) {
        return filterChipX(right) - chipWidth(refreshChipLabel(), false) - CHIP_GAP;
    }

    private static final class ChipFlow {
        private final int startX;
        private final int maxRight;
        private int x;
        private int y;

        private ChipFlow(int startX, int y, int maxRight) {
            this.startX = startX;
            this.x = startX;
            this.y = y;
            this.maxRight = maxRight;
        }

        private int place(int width) {
            if (x != startX && (x + width) > maxRight) {
                x = startX;
                y += FILTER_ROW_PITCH;
            }
            return x;
        }

        private void advance(int width) {
            x += width + CHIP_GAP;
        }
    }

    private boolean handleTrackingActionClick(double mouseX, double mouseY, int right) {
        TrackedShopTarget trackedTarget = PvcFinderClient.trackedTarget();
        if (trackedTarget == null) {
            return false;
        }

        int trackY = trackingSectionY() + 3;
        int stopWidth = chipWidth(class_2561.method_43471("screen.pvcfinder.stop_tracking").getString(), false);
        int stopX = right - stopWidth - 24;
        if (isInside(mouseX, mouseY, stopX, trackY, stopWidth, CHIP_HEIGHT)) {
            PvcFinderClient.clearTrackingFromScreen(field_22787);
            refreshList();
            return true;
        }
        return false;
    }

    private int marketStatusAccent() {
        if (dataStore.isRefreshing()) {
            return COLOR_DIAMOND;
        }
        return switch (dataStore.snapshotSource()) {
            case LIVE -> dataStore.isStale() ? COLOR_ACCENT : COLOR_EMERALD;
            case CACHE -> dataStore.isStale() ? COLOR_DANGER : COLOR_BORDER;
            case BUNDLED -> dataStore.isStale() ? COLOR_DANGER : COLOR_BORDER;
        };
    }

    private boolean shouldRenderSuggestions() {
        return activeContentsOffer == null
                && searchBox != null
                && searchBox.method_25370()
                && searchScope == PvcFinderFilters.SearchScope.ITEM
                && searchQuery.trim().length() >= 2
                && !searchSuggestions.isEmpty();
    }

    private void blurSearchIfNeeded(double mouseX, double mouseY) {
        if (searchBox == null || !searchBox.method_25370()) {
            return;
        }
        if (isInside(mouseX, mouseY, searchBox.method_46426(), searchBox.method_46427(), searchBox.method_25368(), searchBox.method_25364())) {
            return;
        }
        if (shouldRenderSuggestions()) {
            int left = suggestionBoxLeft();
            int top = suggestionBoxTop();
            int width = suggestionBoxWidth();
            int height = 8 + (searchSuggestions.size() * suggestionRowHeight());
            if (isInside(mouseX, mouseY, left, top, width, height)) {
                return;
            }
        }
        searchBox.method_25365(false);
    }

    private boolean focusSearchIfClicked(double mouseX, double mouseY, class_11909 event, boolean doubleClick) {
        if (searchBox == null || !isInside(mouseX, mouseY, searchBox.method_46426(), searchBox.method_46427(), searchBox.method_25368(), searchBox.method_25364())) {
            return false;
        }
        method_25395(searchBox);
        searchBox.method_25365(true);
        return searchBox.method_25402(event, doubleClick);
    }

    private boolean isInside(double mouseX, double mouseY, int x, int y, int width, int height) {
        return mouseX >= x && mouseX < (x + width) && mouseY >= y && mouseY < (y + height);
    }

    private void drawTrimmed(class_332 guiGraphics, String text, int x, int y, int maxWidth, int color) {
        guiGraphics.method_51433(field_22793, field_22793.method_27523(text, Math.max(maxWidth, 30)), x, y, color, false);
    }

    private final class OfferList extends class_4265<OfferEntry> {
        private OfferList(class_310 minecraft, int width, int height, int y0, int itemHeight) {
            super(minecraft, width, height, y0, itemHeight);
            this.field_22744 = false;
        }

        @Override
        public int method_25322() {
            return Math.max(320, PvcFinderScreen.this.panelWidth() - 40);
        }

        @Override
        protected int method_65507() {
            return (PvcFinderScreen.this.field_22789 + method_25322()) / 2 + 4;
        }

        @Override
        protected void method_57715(class_332 guiGraphics) {
        }

        @Override
        protected void method_57713(class_332 guiGraphics) {
        }

        private int entryCount() {
            return method_25396().size();
        }
    }

    private final class OfferEntry extends class_4265.class_4266<OfferEntry> {
        private final PvcOffer offer;
        private final class_4185 trackButton;
        private final class_4185 contentsButton;

        private OfferEntry(PvcOffer offer) {
            this.offer = offer;
            this.trackButton = class_4185.method_46430(class_2561.method_43471("screen.pvcfinder.track"), button -> {
                PvcFinderClient.toggleTracking(field_22787, offer);
                button.method_25355(trackLabel());
                refreshList();
            }).method_46434(0, 0, TRACK_BUTTON_WIDTH, ACTION_BUTTON_HEIGHT).method_46431();
            this.contentsButton = offer.hasPreviewContents()
                    ? class_4185.method_46430(class_2561.method_43471("screen.pvcfinder.contents"), button -> openContentsPreview(offer))
                    .method_46434(0, 0, CONTENTS_BUTTON_WIDTH, ACTION_BUTTON_HEIGHT)
                    .method_46431()
                    : null;
        }

        @Override
        public void method_25343(class_332 guiGraphics, int mouseX, int mouseY, boolean hovered, float partialTick) {
            int left = method_46426();
            int top = method_46427();
            int width = method_25368();
            int height = method_25364();
            boolean tracked = PvcFinderClient.isTracked(offer);
            boolean compact = width <= 760;
            int background = hovered ? 0xE21A1209 : 0xD717110C;
            int accent = tracked ? COLOR_ACCENT : COLOR_BORDER;
            int iconBoxLeft = left + 10;
            int iconBoxRight = left + 58;
            int summaryPanelWidth = compact ? 116 : SUMMARY_PANEL_WIDTH;
            int summaryPanelLeft = left + width - summaryPanelWidth;
            int textLeft = left + 72;
            int textRight = compact ? (left + width - 14) : (summaryPanelLeft - 12);

            guiGraphics.method_25294(left, top, left + width, top + height - 4, background);
            guiGraphics.method_25294(left, top, left + width, top + 3, accent);
            guiGraphics.method_25294(left + 1, top + height - 5, left + width - 1, top + height - 4, COLOR_BORDER);
            guiGraphics.method_25294(iconBoxLeft, top + 10, iconBoxRight, top + 54, 0xCC10151E);
            guiGraphics.method_25294(iconBoxLeft, top + 10, iconBoxRight, top + 12, tracked ? COLOR_ACCENT : COLOR_DIAMOND);
            int summaryTop = top + 8;
            int summaryBottom = compact ? (top + 48) : (top + height - 8);
            guiGraphics.method_25294(summaryPanelLeft, summaryTop, left + width - 10, summaryBottom, 0xD0152018);
            guiGraphics.method_25294(summaryPanelLeft, summaryTop, left + width - 10, summaryTop + 2, offer.stock() > 0 ? COLOR_EMERALD : COLOR_DANGER);

            class_1799 stack = offer.resultItem().toItemStack();
            guiGraphics.method_51427(stack, iconBoxLeft + 11, top + 19);

            drawTrimmed(guiGraphics, offer.title(), textLeft, top + 12, textRight - textLeft, COLOR_TEXT_BRIGHT);
            drawTrimmed(guiGraphics, offer.priceLabel(), textLeft, top + 25, textRight - textLeft, COLOR_ACCENT);
            drawTrimmed(guiGraphics, offer.shop().displayName() + "  |  " + offer.shop().displayOwner(), textLeft, top + 39, textRight - textLeft, COLOR_TEXT);
            drawTrimmed(
                    guiGraphics,
                    offer.shop().dimensionLabel() + "  |  " + offer.shop().coordsLabel() + "  |  " + PvcFinderClient.offerDistanceLabel(field_22787, offer),
                    textLeft,
                    top + 52,
                    textRight - textLeft,
                    offer.stock() > 0 ? COLOR_TEXT_MUTED : COLOR_DANGER
            );

            int summaryCenterX = summaryPanelLeft + ((left + width - 10 - summaryPanelLeft) / 2);
            guiGraphics.method_25300(field_22793, "STOCK", summaryCenterX, top + 14, COLOR_TEXT_GHOST);
            guiGraphics.method_25300(field_22793, offer.stock() > 0 ? String.valueOf(offer.stock()) : "0", summaryCenterX, top + 27, offer.stock() > 0 ? COLOR_EMERALD : COLOR_DANGER);
            guiGraphics.method_25300(field_22793, tracked ? "TRACKED" : "READY", summaryCenterX, top + 40, tracked ? COLOR_ACCENT : COLOR_TEXT);

            int buttonY = compact ? (top + 72) : (top + 52);
            int actionAreaLeft = compact ? textLeft : summaryPanelLeft;
            int actionAreaRight = compact ? (left + width - 12) : (left + width - 10);
            int actionAreaWidth = actionAreaRight - actionAreaLeft;
            if (contentsButton != null) {
                int actionWidth = CONTENTS_BUTTON_WIDTH + ACTION_BUTTON_GAP + TRACK_BUTTON_WIDTH;
                int actionsLeft = actionAreaLeft + Math.max(0, class_3532.method_15375((actionAreaWidth - actionWidth) / 2.0F));
                int contentsX = actionsLeft;
                int trackX = contentsX + CONTENTS_BUTTON_WIDTH + ACTION_BUTTON_GAP;
                contentsButton.method_46421(contentsX);
                contentsButton.method_46419(buttonY);
                trackButton.method_46421(trackX);
                trackButton.method_46419(buttonY);
                renderActionButton(guiGraphics, mouseX, mouseY, contentsButton, false, COLOR_DIAMOND);
            } else {
                int buttonX = actionAreaLeft + Math.max(0, class_3532.method_15375((actionAreaWidth - TRACK_BUTTON_WIDTH) / 2.0F));
                trackButton.method_46421(buttonX);
                trackButton.method_46419(buttonY);
            }
            trackButton.method_25355(trackLabel());
            renderActionButton(guiGraphics, mouseX, mouseY, trackButton, tracked, tracked ? COLOR_ACCENT : COLOR_BORDER);
        }

        @Override
        public List<? extends class_364> method_25396() {
            return contentsButton == null ? List.of(trackButton) : List.of(trackButton, contentsButton);
        }

        @Override
        public List<? extends class_6379> method_37025() {
            return contentsButton == null ? List.of(trackButton) : List.of(trackButton, contentsButton);
        }

        private class_2561 trackLabel() {
            return PvcFinderClient.isTracked(offer)
                    ? class_2561.method_43470("Stop")
                    : class_2561.method_43471("screen.pvcfinder.track");
        }

        private void renderActionButton(class_332 guiGraphics, int mouseX, int mouseY, class_4185 button, boolean active, int accent) {
            int x = button.method_46426();
            int y = button.method_46427();
            int width = button.method_25368();
            boolean hovered = isInside(mouseX, mouseY, x, y, width, ACTION_BUTTON_HEIGHT);
            int body = active ? 0xFF3C2413 : 0xFF21160D;
            guiGraphics.method_25294(x, y, x + width, y + ACTION_BUTTON_HEIGHT, body);
            guiGraphics.method_25294(x, y, x + width, y + 2, accent);
            guiGraphics.method_25294(x, y, x + 2, y + ACTION_BUTTON_HEIGHT, accent);
            guiGraphics.method_25294(x + width - 2, y, x + width, y + ACTION_BUTTON_HEIGHT, accent);
            guiGraphics.method_25294(x, y + ACTION_BUTTON_HEIGHT - 2, x + width, y + ACTION_BUTTON_HEIGHT, accent);
            if (hovered) {
                guiGraphics.method_25294(x + 2, y + 2, x + width - 2, y + ACTION_BUTTON_HEIGHT - 2, 0x24000000);
            }
            guiGraphics.method_25300(
                    field_22793,
                    field_22793.method_27523(button.method_25369().getString(), width - 12),
                    x + (width / 2),
                    y + 6,
                    active ? COLOR_TEXT_BRIGHT : COLOR_TEXT
            );
        }
    }
}
