package club.peacefulvanilla.pvcfinder.client;

import java.util.List;
import java.util.UUID;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1844;
import net.minecraft.class_1847;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2902;
import net.minecraft.class_310;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_4050;
import net.minecraft.class_638;
import net.minecraft.class_746;

public final class ImaginaryFriendController {
    private static final int FRIEND_ENTITY_ID_BASE = -904201;
    private static final double FOLLOW_DISTANCE = 4.2D;
    private static final double IDLE_RADIUS = 4.35D;
    private static final double IDLE_SWAY_SPEED = 0.018D;
    private static final double IDLE_BOB = 0.32D;
    private static final double TELEPORT_DISTANCE_SQR = 28.0D * 28.0D;
    private static final double MAX_HEIGHT_DELTA = 5.5D;
    private static final int ITEM_ROTATION_TICKS = 20 * 45;
    private static final int SPECIAL_MIN_COOLDOWN = 48;
    private static final int EAT_SOUND_INTERVAL = 7;
    private static final int DANCE_STEP_TICKS = 7;
    private static final int PARTY_SIZE = 13;

    private static final List<PartyGuest> PARTY = List.of(
            new PartyGuest(0, ImaginaryFriendPlayer.JESUS_PROFILE),
            new PartyGuest(1, ImaginaryFriendPlayer.PartyProfile.online("Flynn")),
            new PartyGuest(2, ImaginaryFriendPlayer.PartyProfile.online("CarbonFang")),
            new PartyGuest(3, ImaginaryFriendPlayer.PartyProfile.online("generaldage")),
            new PartyGuest(4, ImaginaryFriendPlayer.PartyProfile.online("maybaer")),
            new PartyGuest(5, ImaginaryFriendPlayer.PartyProfile.online("BarbieTau")),
            new PartyGuest(6, ImaginaryFriendPlayer.PartyProfile.online("Marshall_cpp")),
            new PartyGuest(7, ImaginaryFriendPlayer.PartyProfile.online("KingNeme")),
            new PartyGuest(8, ImaginaryFriendPlayer.PartyProfile.online("zDavidMeson")),
            new PartyGuest(9, ImaginaryFriendPlayer.PartyProfile.online("tobiasvsk", UUID.fromString("172fe75a-ddec-4598-bc8c-21d7a2034625"))),
            new PartyGuest(10, ImaginaryFriendPlayer.PartyProfile.online("HippotheGamer")),
            new PartyGuest(11, ImaginaryFriendPlayer.PartyProfile.online("Loveweird")),
            new PartyGuest(12, ImaginaryFriendPlayer.PartyProfile.online("Gog333"))
    );

    private static boolean enabled;

    private ImaginaryFriendController() {
    }

    public static boolean isActive() {
        return enabled;
    }

    public static boolean toggle(class_310 minecraft) {
        if (enabled) {
            disable(minecraft, true);
            return false;
        }
        return enable(minecraft, true);
    }

    public static void tick(class_310 minecraft) {
        if (!enabled) {
            return;
        }
        if (minecraft.field_1687 == null || minecraft.field_1724 == null) {
            removePartyEntities();
            return;
        }

        class_638 level = minecraft.field_1687;
        class_746 player = minecraft.field_1724;
        if (needsPartyRespawn(level)) {
            if (!spawnParty(level, player)) {
                return;
            }
        }

        for (PartyGuest guest : PARTY) {
            tickHeldItem(level, guest);
            tickBehaviorSelection(level, player, guest);
            applyBehavior(level, player, guest);
        }
    }

    private static boolean enable(class_310 minecraft, boolean announce) {
        if (minecraft.field_1687 == null || minecraft.field_1724 == null) {
            return false;
        }
        enabled = true;
        if (!spawnParty(minecraft.field_1687, minecraft.field_1724)) {
            enabled = false;
            return false;
        }
        if (announce) {
            minecraft.field_1724.method_7353(class_2561.method_43471("message.pvcfinder.party_spawned"), true);
        }
        return true;
    }

    private static void disable(class_310 minecraft, boolean announce) {
        enabled = false;
        for (PartyGuest guest : PARTY) {
            guest.reset();
        }
        removePartyEntities();
        if (announce && minecraft.field_1724 != null) {
            minecraft.field_1724.method_7353(class_2561.method_43471("message.pvcfinder.party_despawned"), true);
        }
    }

    private static boolean needsPartyRespawn(class_638 level) {
        for (PartyGuest guest : PARTY) {
            if (guest.friend == null || guest.friend.method_31481() || guest.friend.method_73183() != level) {
                return true;
            }
        }
        return false;
    }

    private static boolean spawnParty(class_638 level, class_746 player) {
        removePartyEntities();
        for (PartyGuest guest : PARTY) {
            guest.prepare(player);
            guest.friend = new ImaginaryFriendPlayer(level, guest.profile);
            guest.friend.method_5838(FRIEND_ENTITY_ID_BASE - guest.index);
            guest.friend.method_5826(guest.profile.entityId());
            equipHeldItem(guest);
            teleportFriend(guest, followTarget(level, player, guest), player);
            level.method_53875(guest.friend);
            if (!level.method_18456().contains(guest.friend)) {
                level.method_18456().add(guest.friend);
            }
        }
        return true;
    }

    private static void removePartyEntities() {
        for (PartyGuest guest : PARTY) {
            removeFriendEntity(guest);
        }
    }

    private static void removeFriendEntity(PartyGuest guest) {
        if (guest.friend == null) {
            return;
        }
        if (guest.friend.method_73183() instanceof class_638 level) {
            level.method_18456().remove(guest.friend);
            if (level.method_8469(guest.friend.method_5628()) != null) {
                level.method_2945(guest.friend.method_5628(), class_1297.class_5529.field_26999);
            }
        }
        guest.friend = null;
    }

    private static void tickHeldItem(class_638 level, PartyGuest guest) {
        if (guest.friend == null) {
            return;
        }
        if (guest.behavior == FriendBehavior.EAT || guest.behavior == FriendBehavior.DRINK) {
            return;
        }
        if (--guest.itemRotationTicks > 0) {
            equipHeldItem(guest);
            return;
        }

        guest.heldItemIndex = (guest.heldItemIndex + 1) % 5;
        guest.itemRotationTicks = ITEM_ROTATION_TICKS + (guest.index * 11);
        equipHeldItem(guest);
        if (guest.heldItemIndex == 1) {
            level.method_55116(guest.friend, class_3417.field_14931, class_3419.field_15248, 0.12F, 1.55F);
            spawnPartySparkles(level, guest);
        } else if (guest.heldItemIndex == 2) {
            level.method_55116(guest.friend, class_3417.field_14660, class_3419.field_15248, 0.09F, 1.15F);
        }
    }

    private static void equipHeldItem(PartyGuest guest) {
        if (guest.friend == null) {
            return;
        }
        guest.friend.method_6021();
        guest.friend.method_6122(class_1268.field_5808, switch (guest.heldItemIndex) {
            case 1 -> new class_1799(class_1802.field_8288);
            case 2 -> new class_1799(class_1802.field_8209);
            case 3 -> class_1844.method_57400(class_1802.field_8574, class_1847.field_8986);
            case 4 -> new class_1799(class_1802.field_8601);
            default -> new class_1799(class_1802.field_8229);
        });
    }

    private static void tickBehaviorSelection(class_638 level, class_746 player, PartyGuest guest) {
        if (guest.friend == null) {
            return;
        }
        if (guest.behaviorCooldownTicks > 0) {
            guest.behaviorCooldownTicks--;
        }

        if (guest.behavior != FriendBehavior.FOLLOW) {
            if (requiresStableGround(guest.behavior) && !isStableOnGround(guest)) {
                endBehavior(guest);
                return;
            }
            if (guest.friend.method_73189().method_1025(player.method_73189()) > 16.0D * 16.0D) {
                endBehavior(guest);
                return;
            }
            if (--guest.behaviorTicksRemaining <= 0) {
                endBehavior(guest);
            }
            return;
        }

        if (guest.behaviorCooldownTicks > 0 || !isStableOnGround(guest)) {
            return;
        }

        int roll = level.field_9229.method_43048(360);
        if (roll < 18) {
            startBehavior(guest, FriendBehavior.DANCE, 34 + level.field_9229.method_43048(46), guest.friend.method_73189());
            if ((guest.index % 4) == 0) {
                level.method_55116(guest.friend, class_3417.field_14793.comp_349(), class_3419.field_15248, 0.18F, 1.35F + (level.field_9229.method_43057() * 0.4F));
            }
            return;
        }
        if (roll < 22) {
            startBehavior(guest, FriendBehavior.OBSERVE, 38 + level.field_9229.method_43048(42), guest.friend.method_73189());
            guest.observeYaw = guest.friend.method_5791() + (level.field_9229.method_43056() ? 55.0F : -55.0F);
            return;
        }
        if (roll < 28) {
            startBehavior(guest, FriendBehavior.CROUCH, 24 + level.field_9229.method_43048(22), guest.friend.method_73189());
            return;
        }
        if (roll < 32) {
            startBehavior(guest, FriendBehavior.EAT, 24 + level.field_9229.method_43048(10), guest.friend.method_73189());
            guest.friend.method_6122(class_1268.field_5808, new class_1799(class_1802.field_8229));
            guest.friend.method_6019(class_1268.field_5808);
            return;
        }
        if (roll < 35) {
            startBehavior(guest, FriendBehavior.DRINK, 28 + level.field_9229.method_43048(8), guest.friend.method_73189());
            guest.friend.method_6122(class_1268.field_5808, class_1844.method_57400(class_1802.field_8574, class_1847.field_8986));
            guest.friend.method_6019(class_1268.field_5808);
            level.method_55116(guest.friend, class_3417.field_14565, class_3419.field_15248, 0.12F, 1.15F);
            return;
        }
        if (roll < 44) {
            class_243 wanderTarget = guest.friend.method_73189().method_1031(
                    (level.field_9229.method_43058() - 0.5D) * 3.8D,
                    0.0D,
                    (level.field_9229.method_43058() - 0.5D) * 3.8D
            );
            startBehavior(guest, FriendBehavior.WANDER, 42 + level.field_9229.method_43048(34), snapToGround(level, player.method_73189(), wanderTarget));
        }
    }

    private static void applyBehavior(class_638 level, class_746 player, PartyGuest guest) {
        if (guest.friend == null) {
            return;
        }

        class_243 desired = switch (guest.behavior) {
            case FOLLOW -> followTarget(level, player, guest);
            case WANDER -> guest.behaviorAnchor == null ? followTarget(level, player, guest) : guest.behaviorAnchor;
            default -> guest.behaviorAnchor == null ? guest.friend.method_73189() : guest.behaviorAnchor;
        };

        if (guest.friend.method_73189().method_1025(player.method_73189()) > TELEPORT_DISTANCE_SQR || guest.friend.method_23318() < level.method_31607() - 8.0D) {
            endBehavior(guest);
            teleportFriend(guest, followTarget(level, player, guest), player);
            return;
        }

        if (guest.behavior == FriendBehavior.FOLLOW || guest.behavior == FriendBehavior.WANDER) {
            stepFriend(level, player, guest, desired);
            return;
        }

        holdPose(level, player, guest, desired);
    }

    private static void stepFriend(class_638 level, class_746 player, PartyGuest guest, class_243 target) {
        if (guest.friend == null) {
            return;
        }

        clearPoseOverrides(guest);
        equipHeldItem(guest);

        class_243 offset = target.method_1020(guest.friend.method_73189());
        double horizontalDistance = Math.hypot(offset.field_1352, offset.field_1350);
        float moveYaw = lookYaw(guest.friend.method_73189(), target);
        float lookYaw = lookYaw(guest.friend.method_73189(), player.method_73189());
        float bodyYaw = class_3532.method_15388(guest.friend.method_36454(), moveYaw, horizontalDistance > 1.65D ? 14.0F : 8.0F);

        guest.friend.method_36457(0.0F);
        guest.friend.method_36456(bodyYaw);
        guest.friend.method_5636(bodyYaw);
        guest.friend.method_5847(class_3532.method_15388(guest.friend.method_5791(), lookYaw, 18.0F));
        guest.friend.method_5728(horizontalDistance > 2.4D || player.method_5624());

        if ((offset.field_1351 > 0.45D || guest.friend.field_5976) && guest.friend.method_24828()) {
            guest.friend.method_6043();
        }

        if (horizontalDistance > 0.22D) {
            float speed = horizontalDistance > 3.2D ? 0.24F : horizontalDistance > 1.9D ? 0.17F : 0.11F;
            if (player.method_5624()) {
                speed += 0.03F;
            }
            guest.friend.method_6125(speed);
            guest.friend.method_6091(new class_243(0.0D, 0.0D, 1.0D));
            applyDancePose(level, player, guest, horizontalDistance < 1.35D);
            return;
        }

        class_243 velocity = guest.friend.method_18798();
        guest.friend.method_6125(0.0F);
        guest.friend.method_18800(velocity.field_1352 * 0.38D, velocity.field_1351, velocity.field_1350 * 0.38D);
        guest.friend.method_6091(class_243.field_1353);
        applyDancePose(level, player, guest, true);
    }

    private static void holdPose(class_638 level, class_746 player, PartyGuest guest, class_243 target) {
        if (guest.friend == null) {
            return;
        }
        if (requiresStableGround(guest.behavior) && !isStableOnGround(guest)) {
            endBehavior(guest);
            return;
        }

        class_243 anchor = target == null ? guest.friend.method_73189() : target;
        teleportFriend(guest, anchor, player);
        guest.friend.method_5728(false);
        guest.friend.method_6125(0.0F);
        guest.friend.method_18799(class_243.field_1353);
        guest.friend.method_6091(class_243.field_1353);

        float lookYawToPlayer = lookYaw(guest.friend.method_73189(), player.method_73189());
        float bodyYaw = class_3532.method_15388(guest.friend.field_6283, lookYawToPlayer, 8.0F);
        guest.friend.field_6283 = bodyYaw;
        guest.friend.field_6220 = bodyYaw;
        guest.friend.method_36456(bodyYaw);

        switch (guest.behavior) {
            case OBSERVE -> {
                clearPoseOverrides(guest);
                guest.friend.method_5847(class_3532.method_15388(guest.friend.method_5791(), guest.observeYaw, 5.0F));
                if ((guest.behaviorTicksRemaining % 14) == 0) {
                    guest.observeYaw += level.field_9229.method_43056() ? 18.0F : -18.0F;
                }
            }
            case DANCE -> {
                applyDancePose(level, player, guest, true);
                guest.friend.method_5847(class_3532.method_15388(guest.friend.method_5791(), lookYawToPlayer, 10.0F));
                if ((guest.behaviorTicksRemaining % 12) == 0) {
                    guest.friend.method_23667(class_1268.field_5808, true);
                    spawnPartySparkles(level, guest);
                }
            }
            case CROUCH -> {
                guest.friend.method_5660((player.field_6012 + guest.index) % 10 < 5);
                guest.friend.method_18380(guest.friend.method_5715() ? class_4050.field_18081 : class_4050.field_18076);
                guest.friend.method_5847(class_3532.method_15388(guest.friend.method_5791(), lookYawToPlayer, 6.0F));
            }
            case EAT -> {
                clearPoseOverrides(guest);
                if (guest.friend.method_6014() <= 0) {
                    guest.friend.method_6019(class_1268.field_5808);
                }
                guest.friend.method_5847(class_3532.method_15388(guest.friend.method_5791(), lookYawToPlayer, 6.0F));
                if ((guest.behaviorTicksRemaining % EAT_SOUND_INTERVAL) == 0) {
                    guest.friend.method_23667(class_1268.field_5808, true);
                    level.method_55116(guest.friend, class_3417.field_20614.comp_349(), class_3419.field_15248, 0.34F, 0.9F + (level.field_9229.method_43057() * 0.24F));
                }
                if (guest.behaviorTicksRemaining <= 1) {
                    level.method_55116(guest.friend, class_3417.field_19149, class_3419.field_15248, 0.18F, 1.0F);
                }
            }
            case DRINK -> {
                clearPoseOverrides(guest);
                if (guest.friend.method_6014() <= 0) {
                    guest.friend.method_6019(class_1268.field_5808);
                }
                guest.friend.method_5847(class_3532.method_15388(guest.friend.method_5791(), lookYawToPlayer, 6.0F));
                if ((guest.behaviorTicksRemaining % 10) == 0) {
                    level.method_55116(guest.friend, class_3417.field_20613.comp_349(), class_3419.field_15248, 0.25F, 1.0F + (level.field_9229.method_43057() * 0.1F));
                }
                if ((guest.behaviorTicksRemaining % 12) == 0) {
                    spawnPotionParticles(level, guest);
                }
            }
            default -> clearPoseOverrides(guest);
        }
    }

    private static void applyDancePose(class_638 level, class_746 player, PartyGuest guest, boolean active) {
        if (guest.friend == null) {
            return;
        }
        boolean crouching = active && ((player.field_6012 + guest.index * 4) / DANCE_STEP_TICKS) % 2 == 0;
        guest.friend.method_5660(crouching);
        guest.friend.method_18380(crouching ? class_4050.field_18081 : class_4050.field_18076);
        if (active && ((player.field_6012 + guest.index * 3) % 20) == 0) {
            guest.friend.method_23667(class_1268.field_5808, true);
            if ((guest.index % 5) == 0) {
                level.method_55116(guest.friend, class_3417.field_15204.comp_349(), class_3419.field_15248, 0.08F, 1.5F);
            }
        }
    }

    private static void startBehavior(PartyGuest guest, FriendBehavior next, int durationTicks, class_243 anchor) {
        guest.behavior = next;
        guest.behaviorTicksRemaining = durationTicks;
        guest.behaviorCooldownTicks = SPECIAL_MIN_COOLDOWN + (guest.index * 2);
        guest.behaviorAnchor = anchor;
    }

    private static void endBehavior(PartyGuest guest) {
        if (guest.friend != null) {
            guest.friend.method_6021();
        }
        guest.behavior = FriendBehavior.FOLLOW;
        guest.behaviorTicksRemaining = 0;
        guest.behaviorAnchor = null;
        clearPoseOverrides(guest);
        equipHeldItem(guest);
    }

    private static void clearPoseOverrides(PartyGuest guest) {
        if (guest.friend == null) {
            return;
        }
        guest.friend.method_5660(false);
        guest.friend.method_18380(class_4050.field_18076);
        guest.friend.method_36457(0.0F);
    }

    private static boolean isStableOnGround(PartyGuest guest) {
        if (guest.friend == null) {
            return false;
        }
        return guest.friend.method_24828()
                && !guest.friend.method_6128()
                && !guest.friend.method_5681()
                && !guest.friend.method_5765()
                && Math.abs(guest.friend.method_18798().field_1351) < 0.08D;
    }

    private static boolean requiresStableGround(FriendBehavior behavior) {
        return switch (behavior) {
            case OBSERVE, DANCE, CROUCH, EAT, DRINK -> true;
            default -> false;
        };
    }

    private static class_243 followTarget(class_638 level, class_746 player, PartyGuest guest) {
        class_243 movement = player.method_18798();
        boolean moving = movement.method_37268() > 0.0025D;
        class_243 desired;
        if (moving) {
            class_243 dir = new class_243(movement.field_1352, 0.0D, movement.field_1350).method_1029();
            class_243 side = new class_243(-dir.field_1350, 0.0D, dir.field_1352);
            double sway = Math.sin((player.field_6012 + guest.index * 9) * 0.12D) * 0.28D;
            desired = player.method_73189()
                    .method_1020(dir.method_1021(movingBackOffset(guest.index)))
                    .method_1019(side.method_1021(movingSideOffset(guest.index) + sway));
        } else {
            guest.idleAngle += IDLE_SWAY_SPEED * (0.75D + (guest.index % 4) * 0.08D);
            double radius = IDLE_RADIUS + ((guest.index % 3) * 0.28D) + (Math.sin((player.field_6012 + guest.index * 11) * 0.08D) * IDLE_BOB);
            desired = player.method_73189().method_1031(Math.cos(guest.idleAngle) * radius, 0.0D, Math.sin(guest.idleAngle) * radius);
        }
        return snapToGround(level, player.method_73189(), desired);
    }

    private static double movingBackOffset(int index) {
        return FOLLOW_DISTANCE + ((index / 5) * 1.35D);
    }

    private static double movingSideOffset(int index) {
        int[] columns = {0, -1, 1, -2, 2, 0, -1, 1, -2, 2, 0, -1, 1};
        return columns[index] * 1.35D;
    }

    private static class_243 snapToGround(class_638 level, class_243 anchor, class_243 desired) {
        int probeY = class_3532.method_15357(Math.max(anchor.field_1351 + 3.0D, desired.field_1351 + 3.0D));
        class_2338 probe = class_2338.method_49637(desired.field_1352, probeY, desired.field_1350);
        class_2338 surface = level.method_8598(class_2902.class_2903.field_13203, probe);
        double groundY = surface.method_10264() + 1.0D;
        if (Math.abs(groundY - anchor.field_1351) > MAX_HEIGHT_DELTA) {
            groundY = anchor.field_1351;
        }
        return new class_243(desired.field_1352, groundY, desired.field_1350);
    }

    private static void teleportFriend(PartyGuest guest, class_243 target, class_746 player) {
        if (guest.friend == null) {
            return;
        }
        float yaw = lookYaw(target, player.method_73189());
        guest.friend.method_5859(target.field_1352, target.field_1351, target.field_1350);
        guest.friend.method_5814(target.field_1352, target.field_1351, target.field_1350);
        guest.friend.method_63615(target, yaw, 0.0F);
        guest.friend.method_18799(class_243.field_1353);
        guest.friend.method_38785();
        guest.friend.method_36457(0.0F);
        guest.friend.method_36456(yaw);
        guest.friend.method_5636(yaw);
        guest.friend.method_5847(yaw);
    }

    private static void spawnPartySparkles(class_638 level, PartyGuest guest) {
        if (guest.friend == null) {
            return;
        }
        for (int i = 0; i < 5; i++) {
            double angle = (Math.PI * 2.0D * i) / 5.0D;
            level.method_8494(
                    (i & 1) == 0 ? class_2398.field_11211 : class_2398.field_11207,
                    guest.friend.method_23317() + (Math.cos(angle) * 0.45D),
                    guest.friend.method_23318() + 1.35D + (level.field_9229.method_43058() * 0.5D),
                    guest.friend.method_23321() + (Math.sin(angle) * 0.45D),
                    0.0D,
                    0.02D,
                    0.0D
            );
        }
    }

    private static void spawnPotionParticles(class_638 level, PartyGuest guest) {
        if (guest.friend == null) {
            return;
        }
        for (int i = 0; i < 4; i++) {
            level.method_8494(
                    class_2398.field_11249,
                    guest.friend.method_23317() + ((level.field_9229.method_43058() - 0.5D) * 0.6D),
                    guest.friend.method_23318() + 1.4D + (level.field_9229.method_43058() * 0.3D),
                    guest.friend.method_23321() + ((level.field_9229.method_43058() - 0.5D) * 0.6D),
                    0.0D,
                    0.02D,
                    0.0D
            );
        }
    }

    private static float lookYaw(class_243 from, class_243 to) {
        return (float) (Math.toDegrees(Math.atan2(to.field_1350 - from.field_1350, to.field_1352 - from.field_1352)) - 90.0D);
    }

    private enum FriendBehavior {
        FOLLOW,
        WANDER,
        OBSERVE,
        DANCE,
        CROUCH,
        EAT,
        DRINK
    }

    private static final class PartyGuest {
        private final int index;
        private final ImaginaryFriendPlayer.PartyProfile profile;
        private ImaginaryFriendPlayer friend;
        private double idleAngle;
        private int itemRotationTicks;
        private int heldItemIndex;
        private int behaviorTicksRemaining;
        private int behaviorCooldownTicks;
        private FriendBehavior behavior = FriendBehavior.FOLLOW;
        private class_243 behaviorAnchor;
        private float observeYaw;

        private PartyGuest(int index, ImaginaryFriendPlayer.PartyProfile profile) {
            this.index = index;
            this.profile = profile;
        }

        private void prepare(class_746 player) {
            reset();
            idleAngle = Math.toRadians(player.method_36454() - 90.0F) + ((Math.PI * 2.0D * index) / PARTY_SIZE);
            itemRotationTicks = ITEM_ROTATION_TICKS + (index * 17);
            behaviorCooldownTicks = 35 + (index * 4);
            heldItemIndex = index % 5;
        }

        private void reset() {
            itemRotationTicks = 0;
            heldItemIndex = 0;
            behaviorTicksRemaining = 0;
            behaviorCooldownTicks = 0;
            behavior = FriendBehavior.FOLLOW;
            behaviorAnchor = null;
            observeYaw = 0.0F;
        }
    }
}
