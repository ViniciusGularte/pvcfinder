package club.peacefulvanilla.pvcfinder.client;

import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1844;
import net.minecraft.class_1847;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2902;
import net.minecraft.class_310;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_4050;
import net.minecraft.class_638;
import net.minecraft.class_746;

public final class ImaginaryFriendController {
    private static final int FRIEND_ENTITY_ID = -904201;
    private static final double FOLLOW_DISTANCE = 1.8D;
    private static final double SIDE_OFFSET = 1.05D;
    private static final double IDLE_RADIUS = 1.7D;
    private static final double IDLE_SWAY_SPEED = 0.04D;
    private static final double IDLE_BOB = 0.22D;
    private static final double TELEPORT_DISTANCE_SQR = 18.0D * 18.0D;
    private static final double MAX_HEIGHT_DELTA = 5.5D;
    private static final int ITEM_ROTATION_TICKS = 20 * 60 * 3;
    private static final int SPECIAL_MIN_COOLDOWN = 70;
    private static final int EAT_SOUND_INTERVAL = 7;

    private static ImaginaryFriendPlayer friend;
    private static boolean enabled;
    private static double idleAngle;
    private static int itemRotationTicks;
    private static int heldItemIndex;
    private static int behaviorTicksRemaining;
    private static int behaviorCooldownTicks;
    private static FriendBehavior behavior = FriendBehavior.FOLLOW;
    private static class_243 behaviorAnchor;
    private static float observeYaw;

    private ImaginaryFriendController() {
    }

    public static boolean isActive() {
        return enabled;
    }

    public static boolean toggle(class_310 minecraft) {
        if (enabled) {
            disable(minecraft, true);
            return false;
        }
        return enable(minecraft, true);
    }

    public static void tick(class_310 minecraft) {
        if (!enabled) {
            return;
        }
        if (minecraft.field_1687 == null || minecraft.field_1724 == null) {
            removeFriendEntity();
            return;
        }

        class_638 level = minecraft.field_1687;
        class_746 player = minecraft.field_1724;
        if (friend == null || friend.method_31481() || friend.method_73183() != level) {
            if (!spawnFriend(level, player)) {
                return;
            }
        }

        tickHeldItem(level);
        tickBehaviorSelection(level, player);
        applyBehavior(level, player);
    }

    private static boolean enable(class_310 minecraft, boolean announce) {
        if (minecraft.field_1687 == null || minecraft.field_1724 == null) {
            return false;
        }
        enabled = true;
        if (!spawnFriend(minecraft.field_1687, minecraft.field_1724)) {
            enabled = false;
            return false;
        }
        if (announce) {
            minecraft.field_1724.method_7353(class_2561.method_43471("message.pvcfinder.jesus_spawned"), true);
        }
        return true;
    }

    private static void disable(class_310 minecraft, boolean announce) {
        enabled = false;
        itemRotationTicks = 0;
        behaviorTicksRemaining = 0;
        behaviorCooldownTicks = 0;
        behavior = FriendBehavior.FOLLOW;
        behaviorAnchor = null;
        removeFriendEntity();
        if (announce && minecraft.field_1724 != null) {
            minecraft.field_1724.method_7353(class_2561.method_43471("message.pvcfinder.jesus_despawned"), true);
        }
    }

    private static boolean spawnFriend(class_638 level, class_746 player) {
        removeFriendEntity();
        idleAngle = Math.toRadians(player.method_36454() - 35.0F);
        itemRotationTicks = ITEM_ROTATION_TICKS;
        behaviorTicksRemaining = 0;
        behaviorCooldownTicks = 60;
        behavior = FriendBehavior.FOLLOW;
        heldItemIndex = 0;
        behaviorAnchor = null;
        friend = new ImaginaryFriendPlayer(level);
        friend.method_5838(FRIEND_ENTITY_ID);
        friend.method_5826(ImaginaryFriendPlayer.PROFILE_ID);
        equipHeldItem();
        teleportFriend(followTarget(level, player), player);
        level.method_53875(friend);
        if (!level.method_18456().contains(friend)) {
            level.method_18456().add(friend);
        }
        return true;
    }

    private static void removeFriendEntity() {
        if (friend == null) {
            return;
        }
        if (friend.method_73183() instanceof class_638 level) {
            level.method_18456().remove(friend);
            if (level.method_8469(friend.method_5628()) != null) {
                level.method_2945(friend.method_5628(), class_1297.class_5529.field_26999);
            }
        }
        friend = null;
    }

    private static void tickHeldItem(class_638 level) {
        if (friend == null) {
            return;
        }
        if (behavior == FriendBehavior.EAT || behavior == FriendBehavior.DRINK) {
            return;
        }
        if (--itemRotationTicks > 0) {
            equipHeldItem();
            return;
        }

        heldItemIndex = (heldItemIndex + 1) % 4;
        itemRotationTicks = ITEM_ROTATION_TICKS;
        equipHeldItem();
        if (heldItemIndex == 1) {
            level.method_55116(friend, class_3417.field_14931, class_3419.field_15248, 0.18F, 1.45F);
            spawnSubtleHalo(level);
        } else if (heldItemIndex == 2) {
            level.method_55116(friend, class_3417.field_14660, class_3419.field_15248, 0.12F, 1.15F);
        }
    }

    private static void equipHeldItem() {
        if (friend == null) {
            return;
        }
        friend.method_6021();
        friend.method_6122(class_1268.field_5808, switch (heldItemIndex) {
            case 1 -> new class_1799(class_1802.field_8288);
            case 2 -> new class_1799(class_1802.field_8209);
            case 3 -> class_1844.method_57400(class_1802.field_8574, class_1847.field_8986);
            default -> new class_1799(class_1802.field_8229);
        });
    }

    private static void tickBehaviorSelection(class_638 level, class_746 player) {
        if (friend == null) {
            return;
        }
        if (behaviorCooldownTicks > 0) {
            behaviorCooldownTicks--;
        }

        if (behavior != FriendBehavior.FOLLOW) {
            if (requiresStableGround(behavior) && !isStableOnGround()) {
                endBehavior();
                return;
            }
            if (friend.method_73189().method_1025(player.method_73189()) > 9.0D * 9.0D) {
                endBehavior();
                return;
            }
            if (--behaviorTicksRemaining <= 0) {
                endBehavior();
            }
            return;
        }

        if (behaviorCooldownTicks > 0) {
            return;
        }
        if (!isStableOnGround()) {
            return;
        }

        int roll = level.field_9229.method_43048(420);
        if (roll < 3) {
            startBehavior(FriendBehavior.OBSERVE, 38 + level.field_9229.method_43048(42), friend.method_73189());
            observeYaw = friend.method_5791() + (level.field_9229.method_43056() ? 55.0F : -55.0F);
            return;
        }
        if (roll < 5) {
            startBehavior(FriendBehavior.PRAY, 44 + level.field_9229.method_43048(48), friend.method_73189());
            level.method_55116(friend, class_3417.field_14545, class_3419.field_15248, 0.08F, 1.75F);
            spawnSubtleHalo(level);
            return;
        }
        if (roll < 7) {
            startBehavior(FriendBehavior.CROUCH, 28 + level.field_9229.method_43048(30), friend.method_73189());
            return;
        }
        if (roll < 9) {
            startBehavior(FriendBehavior.SIT, 34 + level.field_9229.method_43048(36), friend.method_73189());
            return;
        }
        if (roll < 13) {
            startBehavior(FriendBehavior.EAT, 24 + level.field_9229.method_43048(10), friend.method_73189());
            friend.method_6122(class_1268.field_5808, new class_1799(class_1802.field_8229));
            friend.method_6019(class_1268.field_5808);
            return;
        }
        if (roll < 16) {
            startBehavior(FriendBehavior.DRINK, 28 + level.field_9229.method_43048(8), friend.method_73189());
            friend.method_6122(class_1268.field_5808, class_1844.method_57400(class_1802.field_8574, class_1847.field_8986));
            friend.method_6019(class_1268.field_5808);
            level.method_55116(friend, class_3417.field_14565, class_3419.field_15248, 0.15F, 1.15F);
            return;
        }
        if (roll < 22) {
            class_243 wanderTarget = friend.method_73189().method_1031(
                    (level.field_9229.method_43058() - 0.5D) * 2.8D,
                    0.0D,
                    (level.field_9229.method_43058() - 0.5D) * 2.8D
            );
            startBehavior(FriendBehavior.WANDER, 42 + level.field_9229.method_43048(34), snapToGround(level, player.method_73189(), wanderTarget));
        }
    }

    private static void applyBehavior(class_638 level, class_746 player) {
        class_243 desired = switch (behavior) {
            case FOLLOW -> followTarget(level, player);
            case WANDER -> behaviorAnchor == null ? followTarget(level, player) : behaviorAnchor;
            default -> behaviorAnchor == null ? friend.method_73189() : behaviorAnchor;
        };

        if (friend.method_73189().method_1025(player.method_73189()) > TELEPORT_DISTANCE_SQR || friend.method_23318() < level.method_31607() - 8.0D) {
            endBehavior();
            teleportFriend(followTarget(level, player), player);
            return;
        }

        if (behavior == FriendBehavior.FOLLOW || behavior == FriendBehavior.WANDER) {
            stepFriend(player, desired);
            return;
        }

        holdPose(level, player, desired);
    }

    private static void stepFriend(class_746 player, class_243 target) {
        if (friend == null) {
            return;
        }

        clearPoseOverrides();
        equipHeldItem();

        class_243 offset = target.method_1020(friend.method_73189());
        double horizontalDistance = Math.hypot(offset.field_1352, offset.field_1350);
        float moveYaw = lookYaw(friend.method_73189(), target);
        float lookYaw = lookYaw(friend.method_73189(), player.method_73189());
        float bodyYaw = class_3532.method_15388(friend.method_36454(), moveYaw, horizontalDistance > 1.25D ? 14.0F : 8.0F);

        friend.method_36457(0.0F);
        friend.method_36456(bodyYaw);
        friend.method_5636(bodyYaw);
        friend.method_5847(class_3532.method_15388(friend.method_5791(), lookYaw, 18.0F));
        friend.method_5728(horizontalDistance > 1.6D || player.method_5624());

        if ((offset.field_1351 > 0.45D || friend.field_5976) && friend.method_24828()) {
            friend.method_6043();
        }

        if (horizontalDistance > 0.18D) {
            float speed = horizontalDistance > 2.4D ? 0.22F : horizontalDistance > 1.4D ? 0.16F : 0.11F;
            if (player.method_5624()) {
                speed += 0.03F;
            }
            friend.method_6125(speed);
            friend.method_6091(new class_243(0.0D, 0.0D, 1.0D));
            return;
        }

        class_243 velocity = friend.method_18798();
        friend.method_6125(0.0F);
        friend.method_18800(velocity.field_1352 * 0.38D, velocity.field_1351, velocity.field_1350 * 0.38D);
        friend.method_6091(class_243.field_1353);
    }

    private static void holdPose(class_638 level, class_746 player, class_243 target) {
        if (friend == null) {
            return;
        }
        if (requiresStableGround(behavior) && !isStableOnGround()) {
            endBehavior();
            return;
        }

        class_243 anchor = target == null ? friend.method_73189() : target;
        teleportFriend(anchor, player);
        friend.method_5728(false);
        friend.method_6125(0.0F);
        friend.method_18799(class_243.field_1353);
        friend.method_6091(class_243.field_1353);

        float lookYawToPlayer = lookYaw(friend.method_73189(), player.method_73189());
        float bodyYaw = class_3532.method_15388(friend.field_6283, lookYawToPlayer, 8.0F);
        friend.field_6283 = bodyYaw;
        friend.field_6220 = bodyYaw;
        friend.method_36456(bodyYaw);

        switch (behavior) {
            case OBSERVE -> {
                clearPoseOverrides();
                friend.method_5847(class_3532.method_15388(friend.method_5791(), observeYaw, 5.0F));
                if ((behaviorTicksRemaining % 14) == 0) {
                    observeYaw += level.field_9229.method_43056() ? 18.0F : -18.0F;
                }
            }
            case PRAY -> {
                clearPoseOverrides();
                friend.method_5847(class_3532.method_15388(friend.method_5791(), lookYawToPlayer, 6.0F));
                friend.method_36457(18.0F);
                if ((behaviorTicksRemaining % 18) == 0) {
                    spawnSubtleHalo(level);
                }
            }
            case CROUCH -> {
                friend.method_5660(true);
                friend.method_18380(class_4050.field_18081);
                friend.method_5847(class_3532.method_15388(friend.method_5791(), lookYawToPlayer, 6.0F));
            }
            case SIT -> {
                friend.method_5660(true);
                friend.method_18380(class_4050.field_40118);
                friend.method_5847(class_3532.method_15388(friend.method_5791(), lookYawToPlayer, 5.0F));
            }
            case EAT -> {
                clearPoseOverrides();
                if (friend.method_6014() <= 0) {
                    friend.method_6019(class_1268.field_5808);
                }
                friend.method_5847(class_3532.method_15388(friend.method_5791(), lookYawToPlayer, 6.0F));
                if ((behaviorTicksRemaining % EAT_SOUND_INTERVAL) == 0) {
                    friend.method_23667(class_1268.field_5808, true);
                    level.method_55116(friend, class_3417.field_20614.comp_349(), class_3419.field_15248, 0.52F, 0.9F + (level.field_9229.method_43057() * 0.24F));
                }
                if (behaviorTicksRemaining <= 1) {
                    level.method_55116(friend, class_3417.field_19149, class_3419.field_15248, 0.28F, 1.0F);
                }
            }
            case DRINK -> {
                clearPoseOverrides();
                if (friend.method_6014() <= 0) {
                    friend.method_6019(class_1268.field_5808);
                }
                friend.method_5847(class_3532.method_15388(friend.method_5791(), lookYawToPlayer, 6.0F));
                if ((behaviorTicksRemaining % 10) == 0) {
                    level.method_55116(friend, class_3417.field_20613.comp_349(), class_3419.field_15248, 0.35F, 1.0F + (level.field_9229.method_43057() * 0.1F));
                }
                if ((behaviorTicksRemaining % 12) == 0) {
                    spawnPotionParticles(level);
                }
            }
            default -> clearPoseOverrides();
        }
    }

    private static void startBehavior(FriendBehavior next, int durationTicks, class_243 anchor) {
        behavior = next;
        behaviorTicksRemaining = durationTicks;
        behaviorCooldownTicks = SPECIAL_MIN_COOLDOWN;
        behaviorAnchor = anchor;
    }

    private static void endBehavior() {
        if (friend != null) {
            friend.method_6021();
        }
        behavior = FriendBehavior.FOLLOW;
        behaviorTicksRemaining = 0;
        behaviorAnchor = null;
        clearPoseOverrides();
        equipHeldItem();
    }

    private static void clearPoseOverrides() {
        if (friend == null) {
            return;
        }
        friend.method_5660(false);
        friend.method_18380(class_4050.field_18076);
        friend.method_36457(0.0F);
    }

    private static boolean isStableOnGround() {
        if (friend == null) {
            return false;
        }
        return friend.method_24828()
                && !friend.method_6128()
                && !friend.method_5681()
                && !friend.method_5765()
                && Math.abs(friend.method_18798().field_1351) < 0.08D;
    }

    private static boolean requiresStableGround(FriendBehavior behavior) {
        return switch (behavior) {
            case OBSERVE, PRAY, CROUCH, SIT, EAT, DRINK -> true;
            default -> false;
        };
    }

    private static class_243 followTarget(class_638 level, class_746 player) {
        class_243 movement = player.method_18798();
        boolean moving = movement.method_37268() > 0.0025D;
        class_243 desired;
        if (moving) {
            class_243 dir = new class_243(movement.field_1352, 0.0D, movement.field_1350).method_1029();
            class_243 side = new class_243(-dir.field_1350, 0.0D, dir.field_1352);
            double sway = Math.sin((player.field_6012 + 11) * 0.12D) * 0.35D;
            desired = player.method_73189()
                    .method_1020(dir.method_1021(FOLLOW_DISTANCE))
                    .method_1019(side.method_1021(SIDE_OFFSET + sway));
        } else {
            idleAngle += IDLE_SWAY_SPEED;
            double radius = IDLE_RADIUS + (Math.sin((player.field_6012 + 11) * 0.08D) * IDLE_BOB);
            desired = player.method_73189().method_1031(Math.cos(idleAngle) * radius, 0.0D, Math.sin(idleAngle) * radius);
        }
        return snapToGround(level, player.method_73189(), desired);
    }

    private static class_243 snapToGround(class_638 level, class_243 anchor, class_243 desired) {
        int probeY = class_3532.method_15357(Math.max(anchor.field_1351 + 3.0D, desired.field_1351 + 3.0D));
        class_2338 probe = class_2338.method_49637(desired.field_1352, probeY, desired.field_1350);
        class_2338 surface = level.method_8598(class_2902.class_2903.field_13203, probe);
        double groundY = surface.method_10264() + 1.0D;
        if (Math.abs(groundY - anchor.field_1351) > MAX_HEIGHT_DELTA) {
            groundY = anchor.field_1351;
        }
        return new class_243(desired.field_1352, groundY, desired.field_1350);
    }

    private static void teleportFriend(class_243 target, class_746 player) {
        if (friend == null) {
            return;
        }
        float yaw = lookYaw(target, player.method_73189());
        friend.method_5859(target.field_1352, target.field_1351, target.field_1350);
        friend.method_5814(target.field_1352, target.field_1351, target.field_1350);
        friend.method_63615(target, yaw, 0.0F);
        friend.method_18799(class_243.field_1353);
        friend.method_38785();
        friend.method_36457(0.0F);
        friend.method_36456(yaw);
        friend.method_5636(yaw);
        friend.method_5847(yaw);
    }

    private static void spawnSubtleHalo(class_638 level) {
        if (friend == null) {
            return;
        }
        for (int i = 0; i < 6; i++) {
            double angle = (Math.PI * 2.0D * i) / 6.0D;
            level.method_8494(
                    class_2398.field_11207,
                    friend.method_23317() + (Math.cos(angle) * 0.45D),
                    friend.method_23318() + 1.85D + (level.field_9229.method_43058() * 0.12D),
                    friend.method_23321() + (Math.sin(angle) * 0.45D),
                    0.0D,
                    0.01D,
                    0.0D
            );
        }
    }

    private static void spawnPotionParticles(class_638 level) {
        if (friend == null) {
            return;
        }
        for (int i = 0; i < 4; i++) {
            level.method_8494(
                    class_2398.field_11249,
                    friend.method_23317() + ((level.field_9229.method_43058() - 0.5D) * 0.6D),
                    friend.method_23318() + 1.4D + (level.field_9229.method_43058() * 0.3D),
                    friend.method_23321() + ((level.field_9229.method_43058() - 0.5D) * 0.6D),
                    0.0D,
                    0.02D,
                    0.0D
            );
        }
    }

    private static float lookYaw(class_243 from, class_243 to) {
        return (float) (Math.toDegrees(Math.atan2(to.field_1350 - from.field_1350, to.field_1352 - from.field_1352)) - 90.0D);
    }

    @SuppressWarnings("unused")
    private static void playLocal(class_638 level, class_3414 sound, float volume, float pitch) {
        level.method_55116(friend, sound, class_3419.field_15248, volume, pitch);
    }

    private enum FriendBehavior {
        FOLLOW,
        WANDER,
        OBSERVE,
        PRAY,
        CROUCH,
        SIT,
        EAT,
        DRINK
    }
}
