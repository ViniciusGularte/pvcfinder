package club.peacefulvanilla.pvcfinder.client;

import club.peacefulvanilla.pvcfinder.data.PvcOffer;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_5321;

public record TrackedShopTarget(
        String offerId,
        String label,
        class_5321<class_1937> dimension,
        class_2338 position
) {
    public static TrackedShopTarget fromOffer(PvcOffer offer) {
        return new TrackedShopTarget(
                offer.id(),
                offer.title() + " @ " + offer.shop().displayName(),
                offer.shop().dimension(),
                offer.shop().position()
        );
    }
}
