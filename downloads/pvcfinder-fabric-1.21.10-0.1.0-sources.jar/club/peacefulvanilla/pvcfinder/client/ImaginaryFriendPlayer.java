package club.peacefulvanilla.pvcfinder.client;

import club.peacefulvanilla.pvcfinder.PvcFinderMod;
import com.mojang.authlib.GameProfile;
import java.nio.charset.StandardCharsets;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.function.Supplier;
import net.minecraft.class_12079;
import net.minecraft.class_1297;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_638;
import net.minecraft.class_745;
import net.minecraft.class_7920;
import net.minecraft.class_8685;
import java.util.UUID;

final class ImaginaryFriendPlayer extends class_745 {
    private static final class_2960 JESUS_SKIN_TEXTURE =
            class_2960.method_60655(PvcFinderMod.MOD_ID, "textures/entity/jesus_friend.png");
    private static final class_12079.class_12081 JESUS_SKIN_ASSET = new class_12079.class_12081() {
        @Override
        public class_2960 comp_3626() {
            return JESUS_SKIN_TEXTURE;
        }

        @Override
        public class_2960 comp_3627() {
            return JESUS_SKIN_TEXTURE;
        }
    };
    private static final class_8685 JESUS_SKIN =
            class_8685.method_74884(JESUS_SKIN_ASSET, null, null, class_7920.field_41123);
    static final PartyProfile JESUS_PROFILE = PartyProfile.local(
            "JesusCraftsPeace",
            UUID.fromString("6ba7f277-6b62-4e06-bcbb-d65fd446854e"),
            JESUS_SKIN
    );

    private volatile Supplier<class_8685> skinSupplier;

    ImaginaryFriendPlayer(class_638 level, PartyProfile profile) {
        super(level, new GameProfile(profile.profileId(), profile.name()));
        skinSupplier = createSkinSupplier(profile);
        field_5960 = false;
        method_5684(true);
        method_5875(false);
        method_5803(true);
    }

    @Override
    public class_8685 method_52814() {
        return skinSupplier.get();
    }

    @Override
    public boolean method_5733() {
        return false;
    }

    @Override
    public boolean method_5810() {
        return false;
    }

    @Override
    public boolean method_5863() {
        return false;
    }

    @Override
    public boolean method_30949(class_1297 entity) {
        return false;
    }

    @Override
    public boolean method_30948(class_1297 entity) {
        return false;
    }

    private Supplier<class_8685> createSkinSupplier(PartyProfile profile) {
        if (profile.localSkin() != null) {
            return profile::localSkin;
        }

        class_310 minecraft = class_310.method_1551();
        GameProfile fallbackProfile = new GameProfile(profile.profileId(), profile.name());
        Supplier<class_8685> fallbackLookup = minecraft.method_1582().method_73544(fallbackProfile, false);
        CompletableFuture
                .supplyAsync(() -> resolveOnlineProfile(minecraft, profile).orElse(fallbackProfile))
                .thenAccept(resolvedProfile ->
                        skinSupplier = minecraft.method_1582().method_73544(resolvedProfile, false)
                );
        return fallbackLookup;
    }

    private Optional<GameProfile> resolveOnlineProfile(class_310 minecraft, PartyProfile profile) {
        try {
            if (profile.onlineId() != null) {
                return minecraft.method_73361().comp_4624().method_73290(profile.onlineId());
            }
            return minecraft.method_73361().comp_4624().method_73289(profile.name());
        } catch (RuntimeException ignored) {
            return Optional.empty();
        }
    }

    record PartyProfile(String name, UUID profileId, UUID entityId, UUID onlineId, class_8685 localSkin) {
        static PartyProfile local(String name, UUID profileId, class_8685 skin) {
            return new PartyProfile(name, profileId, syntheticId("entity", name), null, skin);
        }

        static PartyProfile online(String name) {
            return online(name, null);
        }

        static PartyProfile online(String name, UUID onlineId) {
            UUID profileId = onlineId == null ? syntheticId("profile", name) : onlineId;
            return new PartyProfile(name, profileId, syntheticId("entity", name), onlineId, null);
        }

        private static UUID syntheticId(String scope, String name) {
            return UUID.nameUUIDFromBytes(("pvcfinder-party-" + scope + ":" + name).getBytes(StandardCharsets.UTF_8));
        }
    }
}
