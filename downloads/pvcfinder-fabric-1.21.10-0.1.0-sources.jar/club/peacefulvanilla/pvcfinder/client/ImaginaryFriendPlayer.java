package club.peacefulvanilla.pvcfinder.client;

import club.peacefulvanilla.pvcfinder.PvcFinderMod;
import com.mojang.authlib.GameProfile;
import java.util.UUID;
import net.minecraft.class_12079;
import net.minecraft.class_1297;
import net.minecraft.class_2960;
import net.minecraft.class_638;
import net.minecraft.class_745;
import net.minecraft.class_7920;
import net.minecraft.class_8685;

final class ImaginaryFriendPlayer extends class_745 {
    private static final class_2960 JESUS_SKIN_TEXTURE =
            class_2960.method_60655(PvcFinderMod.MOD_ID, "textures/entity/jesus_friend.png");
    private static final class_12079.class_12081 JESUS_SKIN_ASSET = new class_12079.class_12081() {
        @Override
        public class_2960 comp_3626() {
            return JESUS_SKIN_TEXTURE;
        }

        @Override
        public class_2960 comp_3627() {
            return JESUS_SKIN_TEXTURE;
        }
    };
    private static final class_8685 JESUS_SKIN =
            class_8685.method_74884(JESUS_SKIN_ASSET, null, null, class_7920.field_41123);
    static final UUID PROFILE_ID = UUID.fromString("6ba7f277-6b62-4e06-bcbb-d65fd446854e");

    ImaginaryFriendPlayer(class_638 level) {
        super(level, new GameProfile(PROFILE_ID, "JesusCraftsPeace"));
        field_5960 = false;
        method_5684(true);
        method_5875(false);
        method_5803(true);
    }

    @Override
    public class_8685 method_52814() {
        return JESUS_SKIN;
    }

    @Override
    public boolean method_5733() {
        return false;
    }

    @Override
    public boolean method_5810() {
        return false;
    }

    @Override
    public boolean method_5863() {
        return false;
    }

    @Override
    public boolean method_30949(class_1297 entity) {
        return false;
    }

    @Override
    public boolean method_30948(class_1297 entity) {
        return false;
    }
}
