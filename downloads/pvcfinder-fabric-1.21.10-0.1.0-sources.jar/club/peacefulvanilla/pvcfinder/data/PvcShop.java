package club.peacefulvanilla.pvcfinder.data;

import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_5321;

public record PvcShop(
        String name,
        String owner,
        String worldName,
        class_5321<class_1937> dimension,
        class_2338 position
) {
    public String displayName() {
        return name == null || name.isBlank() ? "Unnamed Shop" : name;
    }

    public String displayOwner() {
        return owner == null || owner.isBlank() ? "Unknown Owner" : owner;
    }

    public String coordsLabel() {
        return position.method_10263() + ", " + position.method_10264() + ", " + position.method_10260();
    }

    public String dimensionLabel() {
        if (class_1937.field_25180.equals(dimension)) {
            return "Nether";
        }
        if (class_1937.field_25181.equals(dimension)) {
            return "End";
        }
        return "Overworld";
    }
}
