package club.peacefulvanilla.pvcfinder.data;

import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public record PvcTradeItem(
        String type,
        String customName,
        int amount,
        List<String> lore
) {
    private static final Pattern SHULKER_CONTENT_LINE = Pattern.compile("^-\\s*(\\d+)x\\s+(.+)$", Pattern.CASE_INSENSITIVE);

    public record ShulkerContent(
            int amount,
            String rawName,
            String displayName,
            String searchText
    ) {
    }

    public String displayName() {
        String trimmedCustomName = customName == null ? "" : customName.trim();
        if (isShulkerBox() && (trimmedCustomName.isBlank() || isGenericShulkerName(trimmedCustomName))) {
            ShulkerContent featuredContent = featuredShulkerContent();
            if (featuredContent != null) {
                return "Shulker of " + featuredContent.displayName();
            }
        }

        if (!trimmedCustomName.isBlank()) {
            return trimmedCustomName;
        }
        return prettifyType(type);
    }

    public String shortLabel() {
        return Math.max(amount, 1) + "x " + displayName();
    }

    public String basicSearchText() {
        return (displayName() + " " + type).toLowerCase(Locale.ROOT);
    }

    public String searchText() {
        return (basicSearchText() + " " + String.join(" ", lore)).toLowerCase(Locale.ROOT);
    }

    public boolean isShulkerBox() {
        return type != null && type.toLowerCase(Locale.ROOT).contains("shulker_box");
    }

    public boolean hasPreviewContents() {
        return isShulkerBox() && lore != null && lore.stream().anyMatch(line -> line != null && !line.isBlank());
    }

    public boolean hasParsedShulkerContents() {
        return !shulkerContents().isEmpty();
    }

    public List<ShulkerContent> shulkerContents() {
        if (!isShulkerBox() || lore == null) {
            return List.of();
        }

        return lore.stream()
                .map(PvcTradeItem::parseShulkerLine)
                .filter(content -> content != null)
                .collect(Collectors.toList());
    }

    public List<String> shulkerExactLabels() {
        return shulkerContents().stream()
                .map(ShulkerContent::displayName)
                .distinct()
                .toList();
    }

    public String shulkerSearchText() {
        return shulkerContents().stream()
                .map(ShulkerContent::searchText)
                .collect(Collectors.joining(" "));
    }

    public List<String> previewContents() {
        List<ShulkerContent> contents = shulkerContents();
        if (!contents.isEmpty()) {
            return contents.stream()
                    .map(entry -> entry.amount() + "x " + entry.displayName())
                    .toList();
        }

        if (lore == null) {
            return List.of();
        }
        return lore.stream()
                .map(line -> line == null ? "" : line.trim())
                .filter(line -> !line.isBlank())
                .collect(Collectors.toList());
    }

    private ShulkerContent featuredShulkerContent() {
        List<ShulkerContent> contents = shulkerContents();
        if (contents.size() == 1) {
            return contents.get(0);
        }
        return null;
    }

    public class_1799 toItemStack() {
        class_2960 location = itemKey(type);
        class_1792 item = location == null ? class_1802.field_8407 : class_7923.field_41178.method_63535(location);
        if (item == null || item == class_1802.field_8162) {
            item = class_1802.field_8407;
        }
        return new class_1799(item, 1);
    }

    private static class_2960 itemKey(String type) {
        if (type == null || type.isBlank()) {
            return null;
        }
        if (type.contains(":")) {
            return class_2960.method_12829(type);
        }
        return class_2960.method_12829("minecraft:" + type.toLowerCase(Locale.ROOT));
    }

    private static ShulkerContent parseShulkerLine(String line) {
        if (line == null) {
            return null;
        }

        String trimmed = line.trim();
        if (trimmed.isBlank()) {
            return null;
        }

        Matcher matcher = SHULKER_CONTENT_LINE.matcher(trimmed);
        if (!matcher.matches()) {
            return null;
        }

        int amount = Integer.parseInt(matcher.group(1));
        String rawName = matcher.group(2).trim();
        String displayName = prettifyShulkerContentName(rawName);
        String searchText = (rawName + " " + displayName).toLowerCase(Locale.ROOT);
        return new ShulkerContent(amount, rawName, displayName, searchText);
    }

    private static boolean isGenericShulkerName(String value) {
        String normalized = value == null ? "" : value.trim().toLowerCase(Locale.ROOT);
        return normalized.endsWith("shulker box");
    }

    private static String prettifyShulkerContentName(String rawName) {
        if (rawName == null || rawName.isBlank()) {
            return "Unknown Item";
        }

        String normalized = rawName.trim();
        if (normalized.contains("_")) {
            return prettifyType(normalized);
        }

        String[] parts = normalized.toLowerCase(Locale.ROOT).split("\\s+");
        StringBuilder builder = new StringBuilder();
        for (String part : parts) {
            if (part.isBlank()) {
                continue;
            }
            if (!builder.isEmpty()) {
                builder.append(' ');
            }
            builder.append(Character.toUpperCase(part.charAt(0)));
            if (part.length() > 1) {
                builder.append(part.substring(1));
            }
        }
        return builder.isEmpty() ? normalized : builder.toString();
    }

    private static String prettifyType(String rawType) {
        if (rawType == null || rawType.isBlank()) {
            return "Unknown Item";
        }

        String[] parts = rawType.toLowerCase(Locale.ROOT).split("_");
        StringBuilder builder = new StringBuilder();
        for (String part : parts) {
            if (part.isBlank()) {
                continue;
            }
            if (!builder.isEmpty()) {
                builder.append(' ');
            }
            builder.append(Character.toUpperCase(part.charAt(0)));
            if (part.length() > 1) {
                builder.append(part.substring(1));
            }
        }
        return builder.toString();
    }
}
